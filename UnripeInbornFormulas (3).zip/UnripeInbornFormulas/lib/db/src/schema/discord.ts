import { createInsertSchema } from "drizzle-zod";
import { boolean, integer, pgTable, text, timestamp, primaryKey } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const guildConfigsTable = pgTable("guild_configs", {
  guildId: text("guild_id").primaryKey(),
  enabled: boolean("enabled").notNull().default(true),
  verifyChannelId: text("verify_channel_id"),
  verifyRoleId: text("verify_role_id"),
  verifyMessage: text("verify_message").notNull().default("Klicke auf den Button, um dich zu verifizieren."),
  buttonLabel: text("button_label").notNull().default("Verifizieren"),
  autoRoleEnabled: boolean("auto_role_enabled").notNull().default(true),
  autoReinviteEnabled: boolean("auto_reinvite_enabled").notNull().default(false),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const guildActivityTable = pgTable("guild_activity", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  guildId: text("guild_id").notNull(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  actor: text("actor"),
});

export const guildMembersTable = pgTable("guild_members", {
  guildId: text("guild_id").notNull(),
  userId: text("user_id").notNull(),
  username: text("username").notNull(),
  avatar: text("avatar"),
  verifiedAt: timestamp("verified_at", { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
  leftAt: timestamp("left_at", { withTimezone: true }),
  nextReinviteAt: timestamp("next_reinvite_at", { withTimezone: true }),
  lastInviteAt: timestamp("last_invite_at", { withTimezone: true }),
  inviteCount: integer("invite_count").notNull().default(0),
}, (table) => [
  primaryKey({ columns: [table.guildId, table.userId] }),
]);

export const insertGuildConfigSchema = createInsertSchema(guildConfigsTable).omit({
  updatedAt: true,
});
export const insertGuildActivitySchema = createInsertSchema(guildActivityTable).omit({
  createdAt: true,
});

export type GuildConfig = z.infer<typeof insertGuildConfigSchema>;
export type GuildActivity = typeof guildActivityTable.$inferSelect;