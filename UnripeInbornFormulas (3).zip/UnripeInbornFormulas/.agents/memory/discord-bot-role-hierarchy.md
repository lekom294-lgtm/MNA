---
name: Discord bot role hierarchy
description: Discord bot role permissions and role-position rules needed when creating or assigning verification roles
---

Discord’s bot role can be marked `managed`, but it still determines the bot’s role hierarchy and must be used when checking whether the bot can assign another role.

**Why:** Excluding managed bot roles makes a valid bot appear to have no usable role and causes false “role is above the bot” setup failures.

**How to apply:** Include the bot’s managed role when finding its highest role and effective permissions. Exclude managed roles only when selecting a user-facing Verify role to create or reuse.