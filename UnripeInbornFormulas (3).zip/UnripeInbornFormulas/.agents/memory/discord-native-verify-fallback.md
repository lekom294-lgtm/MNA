---
name: Discord-native verify fallback
description: Core verification behavior when the production database is unavailable
---

The Verify button carries its target role ID in a `discord_verify:<roleId>` custom ID. Setup can create Discord resources without persistence, and button clicks can assign the role without reading PostgreSQL. When the database is unavailable, dashboard membership and counts can use the current Discord role state. Discord's List Guild Members endpoint does not support a `role_id` filter: paginate with `after` and `limit`, then inspect each member's `roles`.

This live fallback reports current role membership, not exact verification history. Activity and reinvite history remain database-backed, and missing verification rows are not automatically backfilled.

**Why:** A paused database should not block role assignment or make a successfully verified member disappear from current dashboard status; Discord's member-list API requires pagination and cannot filter by role server-side.

**How to apply:** Keep database writes best-effort for setup and verification activity. Derive current dashboard membership from the Discord role when needed, but do not present live role state as durable activity or reinvite history.