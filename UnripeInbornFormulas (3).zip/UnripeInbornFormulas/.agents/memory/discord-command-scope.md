---
name: Discord command scope
description: Slash command registration scope for the Verifyline bot
---

Verifyline commands are authoritative per guild, not global. The production gateway should replace each guild’s command list and clear the global command list.

**Why:** Registering the same commands globally and per guild makes Discord display duplicate commands and can route interactions through stale registrations.

**How to apply:** Keep one server-scoped command array, replace it with PUT for each connected guild, and clear old global commands when production starts. Keep preview gateways from registering or handling interactions.