---
name: Discord invite policy
description: Product constraint for reconnecting verified Discord members
---

Verified members must be contacted with personal Discord invitations rather than being moved into a server automatically.

**Why:** Discord requires the member's consent; the bot cannot silently add a user to another server.

**How to apply:** Keep target-server and quantity controls bounded, explain that delivery depends on Discord DM permissions, and never describe an invite campaign as an automatic transfer.