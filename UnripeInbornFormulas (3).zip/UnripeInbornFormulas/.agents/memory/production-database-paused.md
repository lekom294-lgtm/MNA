---
name: Production database pause
description: Replit production PostgreSQL may be frozen or report a disabled endpoint during live Discord bot requests
---

If live Discord commands cannot read or save server configuration and logs report a disabled endpoint, check whether the Replit production database is paused before changing application logic.

**Why:** The production database can freeze after inactivity. Application queries then fail even though the development database and code are healthy.

**How to apply:** Open the Replit Database pane, select the production database, and use “Unpause database”. If no unpause action is available, check for a conflicting `DATABASE_URL` secret. Publish the latest app version after the database is available.