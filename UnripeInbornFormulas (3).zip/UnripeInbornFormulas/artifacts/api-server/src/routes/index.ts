import { Router, type IRouter } from "express";
import healthRouter from "./health";
import discordRouter from "./discord";
import authRouter from "./auth";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(discordRouter);

export default router;
