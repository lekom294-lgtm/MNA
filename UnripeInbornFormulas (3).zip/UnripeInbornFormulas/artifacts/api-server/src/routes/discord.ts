import { Router, type IRouter } from "express";
import type { Request, Response as ExpressResponse } from "express";
import { and, desc, eq, inArray, isNull, lte, sql } from "drizzle-orm";
import { db, guildActivityTable, guildConfigsTable, guildMembersTable } from "@workspace/db";
import {
  GetDiscordMeResponse,
  GetDiscordGuildsResponse,
  GetGuildConfigParams,
  GetGuildConfigResponse,
  UpdateGuildConfigParams,
  UpdateGuildConfigBody,
  UpdateGuildConfigResponse,
  GetGuildStatsParams,
  GetGuildStatsResponse,
  GetGuildActivityParams,
  GetGuildActivityResponse,
  SyncGuildParams,
  SyncGuildResponse,
  GetGuildMembersParams,
  GetGuildMembersQueryParams,
  GetGuildMembersResponse,
  GetVerifiedMembersQueryParams,
  GetVerifiedMembersResponse,
  ReinviteGuildMembersParams,
  ReinviteGuildMembersBody,
  ReinviteGuildMembersResponse,
} from "@workspace/api-zod";
import { getDiscordSession, hasPasswordGate } from "../lib/auth";
import { getConnectedBotGuilds } from "../lib/discord-bot";

const router: IRouter = Router();
const DISCORD_API = "https://discord.com/api/v10";

function discordAvatarUrl(userId: string, avatar: string | null | undefined): string | null {
  return avatar ? `https://cdn.discordapp.com/avatars/${userId}/${avatar}.png?size=128` : null;
}

function discordGuildIconUrl(guildId: string, icon: string | null | undefined): string | null {
  return icon ? `https://cdn.discordapp.com/icons/${guildId}/${icon}.png?size=128` : null;
}

function requireDashboardAccess(req: Request, res: ExpressResponse): boolean {
  if (hasPasswordGate(req) && getDiscordSession(req)) return true;
  res.status(401).json({ error: "Dashboard access required." });
  return false;
}

type DiscordGuild = {
  id: string;
  name: string;
  icon?: string | null;
  memberCount?: number | null;
};

type DiscordRole = {
  id: string;
  name: string;
  managed?: boolean;
  permissions?: string;
};

type DiscordRoleMember = {
  user?: {
    id?: string;
    username?: string;
    avatar?: string | null;
  };
  joined_at?: string;
  roles?: string[];
};

const verifyRoleNames = new Set(["verified", "verifiziert", "verify"]);
const verifiedMembersCache = new Map<
  string,
  { expiresAt: number; members: DiscordRoleMember[]; role?: DiscordRole }
>();
const verifiedMembersInFlight = new Map<
  string,
  Promise<{ role?: DiscordRole; members: DiscordRoleMember[] }>
>();
const VERIFIED_MEMBERS_CACHE_MS = 30_000;

async function discordUserRequest(req: import("express").Request, path: string): Promise<Response> {
  const session = getDiscordSession(req);
  if (!session) {
    throw new Error("Dashboard authentication required");
  }
  return fetch(`${DISCORD_API}${path}`, {
    headers: { Authorization: `Bearer ${session.accessToken}` },
  });
}

async function discordBotRequest(
  path: string,
  init: RequestInit = {},
): Promise<Response> {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) {
    throw new Error("DISCORD_BOT_TOKEN is not configured");
  }

  const headers = new Headers(init.headers);
  headers.set("Authorization", `Bot ${token}`);
  headers.set("Content-Type", "application/json");
  return fetch(`${DISCORD_API}${path}`, { ...init, headers });
}

function getBotGuilds(): DiscordGuild[] {
  return getConnectedBotGuilds().map((guild) => ({
    id: guild.id,
    name: guild.name,
    icon: guild.icon,
    memberCount: guild.memberCount,
  }));
}

async function loadBotGuildPermissions(guildId: string, botUserId: string): Promise<string> {
  const [rolesResponse, memberResponse] = await Promise.all([
    discordBotRequest(`/guilds/${guildId}/roles`),
    discordBotRequest(`/guilds/${guildId}/members/${botUserId}`),
  ]);
  if (!rolesResponse.ok || !memberResponse.ok) {
    throw new Error(`Discord could not load bot permissions (${!rolesResponse.ok ? rolesResponse.status : memberResponse.status})`);
  }

  const roles = await rolesResponse.json() as DiscordRole[];
  const member = await memberResponse.json() as DiscordRoleMember;
  const roleIds = new Set([guildId, ...(member.roles ?? [])]);
  const permissions = roles
    .filter((role) => roleIds.has(role.id))
    .reduce((total, role) => total | BigInt(role.permissions ?? "0"), 0n);
  return permissions.toString();
}

async function findDiscordVerifyRole(
  guildId: string,
  configuredRoleId?: string | null,
): Promise<DiscordRole | undefined> {
  const response = await discordBotRequest(`/guilds/${guildId}/roles`);
  if (!response.ok) {
    throw new Error(`Discord could not load server roles (${response.status})`);
  }
  const roles = await response.json() as DiscordRole[];
  return roles.find((role) =>
    !role.managed && (
      role.id === configuredRoleId
      || verifyRoleNames.has(role.name.trim().toLowerCase())
    ),
  );
}

async function loadDiscordVerifiedMembers(
  guildId: string,
  configuredRoleId?: string | null,
): Promise<{ role?: DiscordRole; members: DiscordRoleMember[] }> {
  const cacheKey = `${guildId}:${configuredRoleId ?? "auto"}`;
  const cached = verifiedMembersCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) {
    return { role: cached.role, members: cached.members };
  }
  const inFlight = verifiedMembersInFlight.get(cacheKey);
  if (inFlight) return inFlight;

  const loadPromise = (async () => {
    const role = await findDiscordVerifyRole(guildId, configuredRoleId);
    if (!role) {
      verifiedMembersCache.set(cacheKey, {
        expiresAt: Date.now() + VERIFIED_MEMBERS_CACHE_MS,
        members: [],
      });
      return { members: [] };
    }

    const members: DiscordRoleMember[] = [];
    let after: string | undefined;
    while (true) {
      const query = new URLSearchParams({ limit: "1000" });
      if (after) query.set("after", after);
      const response = await discordBotRequest(`/guilds/${guildId}/members?${query.toString()}`);
      if (!response.ok) {
        throw new Error(`Discord could not load server members (${response.status})`);
      }
      const page = await response.json() as DiscordRoleMember[];
      members.push(...page.filter((member) => member.roles?.includes(role.id)));
      if (page.length < 1000) break;
      const lastUserId = page.at(-1)?.user?.id;
      if (!lastUserId || lastUserId === after) {
        throw new Error("Discord returned an invalid server-member page");
      }
      after = lastUserId;
    }

    verifiedMembersCache.set(cacheKey, {
      expiresAt: Date.now() + VERIFIED_MEMBERS_CACHE_MS,
      role,
      members,
    });
    return { role, members };
  })();
  verifiedMembersInFlight.set(cacheKey, loadPromise);
  try {
    return await loadPromise;
  } finally {
    verifiedMembersInFlight.delete(cacheKey);
  }
}

function discordVerifiedMemberResponse(
  guildId: string,
  member: DiscordRoleMember,
): GuildMemberResponse {
  const userId = member.user?.id ?? "unknown";
  const verifiedAt = member.joined_at ?? "";
  return {
    guildId,
    userId,
    username: member.user?.username ?? "Discord member",
    avatar: discordAvatarUrl(userId, member.user?.avatar),
    verifiedAt,
    lastSeenAt: verifiedAt,
    leftAt: null,
    nextReinviteAt: null,
    inviteCount: 0,
    status: "active" as const,
  };
}

async function ensureGuildAccess(req: import("express").Request, guildId: string): Promise<DiscordGuild> {
  const guild = getBotGuilds().find((item) => item.id === guildId);
  if (!guild) {
    throw new Error("Discord server access denied");
  }

  return guild;
}

async function getOrCreateConfig(guildId: string) {
  const existing = await db
    .select()
    .from(guildConfigsTable)
    .where(eq(guildConfigsTable.guildId, guildId));
  if (existing[0]) {
    return existing[0];
  }

  const [created] = await db
    .insert(guildConfigsTable)
    .values({ guildId })
    .onConflictDoNothing()
    .returning();
  if (created) {
    return created;
  }

  const [existingAfterRace] = await db
    .select()
    .from(guildConfigsTable)
    .where(eq(guildConfigsTable.guildId, guildId));
  return existingAfterRace;
}

function configResponse(config: typeof guildConfigsTable.$inferSelect) {
  return GetGuildConfigResponse.parse({
    guildId: config.guildId,
    enabled: config.enabled,
    verifyChannelId: config.verifyChannelId,
    verifyRoleId: config.verifyRoleId,
    verifyMessage: config.verifyMessage,
    buttonLabel: config.buttonLabel,
    autoRoleEnabled: config.autoRoleEnabled,
    autoReinviteEnabled: config.autoReinviteEnabled,
    updatedAt: config.updatedAt.toISOString(),
  });
}

function activityResponse(activity: typeof guildActivityTable.$inferSelect) {
  return {
    id: String(activity.id),
    type: activity.type,
    title: activity.title,
    description: activity.description,
    createdAt: activity.createdAt.toISOString(),
    actor: activity.actor,
  };
}

router.get("/discord/me", async (req, res): Promise<void> => {
  try {
    const response = await discordUserRequest(req, "/users/@me");
    if (!response.ok) {
      res.status(401).json({ error: "Discord connection unavailable" });
      return;
    }
    const user = (await response.json()) as {
      id: string;
      username: string;
      global_name?: string | null;
      avatar?: string | null;
    };
    res.json(
      GetDiscordMeResponse.parse({
        id: user.id,
        username: user.username,
        globalName: user.global_name ?? null,
        avatar: discordAvatarUrl(user.id, user.avatar),
      }),
    );
  } catch (error) {
    req.log.error({ err: error }, "Unable to load Discord user");
    res.status(401).json({ error: "Discord connection unavailable" });
  }
});

router.get("/discord/guilds", async (req, res): Promise<void> => {
  if (!requireDashboardAccess(req, res)) return;
  try {
    const guilds = getBotGuilds();
    let botUserId: string | undefined;
    try {
      const currentUserResponse = await discordBotRequest("/users/@me");
      if (currentUserResponse.ok) {
        const currentUser = await currentUserResponse.json() as { id?: string };
        botUserId = currentUser.id;
      }
    } catch (error) {
      req.log.warn({ err: error }, "Unable to identify bot for guild permission checks");
    }
    const withBot = await Promise.all(
      guilds.map(async (guild) => {
        let memberCount = guild.memberCount ?? null;
        let permissions = "0";
        try {
          const [guildResponse, botPermissions] = await Promise.all([
            discordBotRequest(`/guilds/${guild.id}?with_counts=true`),
            botUserId ? loadBotGuildPermissions(guild.id, botUserId) : Promise.resolve("0"),
          ]);
          if (guildResponse.ok) {
            const current = await guildResponse.json() as { approximate_member_count?: number };
            memberCount = current.approximate_member_count ?? memberCount;
          }
          permissions = botPermissions;
        } catch (error) {
          req.log.warn({ err: error, guildId: guild.id }, "Unable to refresh bot guild metadata or permissions");
        }
        return {
          id: guild.id,
          name: guild.name,
          icon: discordGuildIconUrl(guild.id, guild.icon),
          owner: false,
          permissions,
          memberCount,
          botPresent: true,
        };
      }),
    );
    res.json(GetDiscordGuildsResponse.parse(withBot));
  } catch (error) {
    req.log.error({ err: error }, "Unable to load Discord servers");
    res.status(502).json({ error: "Discord servers could not be loaded" });
  }
});

router.get("/discord/guilds/:guildId/config", async (req, res): Promise<void> => {
  const params = GetGuildConfigParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  try {
    await ensureGuildAccess(req, params.data.guildId);
    res.json(configResponse(await getOrCreateConfig(params.data.guildId)));
  } catch (error) {
    req.log.error({ err: error, guildId: params.data.guildId }, "Unable to load guild configuration");
    res.status(403).json({ error: error instanceof Error ? error.message : "Server access denied" });
  }
});

router.put("/discord/guilds/:guildId/config", async (req, res): Promise<void> => {
  const params = UpdateGuildConfigParams.safeParse(req.params);
  const body = UpdateGuildConfigBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }
  try {
    await ensureGuildAccess(req, params.data.guildId);
    const [updated] = await db
      .insert(guildConfigsTable)
      .values({ guildId: params.data.guildId, ...body.data })
      .onConflictDoUpdate({
        target: guildConfigsTable.guildId,
        set: { ...body.data, updatedAt: new Date() },
      })
      .returning();
    await db.insert(guildActivityTable).values({
      guildId: params.data.guildId,
      type: "config_updated",
      title: "Verify-Einstellungen gespeichert",
      description: "Die Einstellungen wurden über das Control Center aktualisiert.",
      actor: "Dashboard",
    });
    res.json(UpdateGuildConfigResponse.parse(configResponse(updated)));
  } catch (error) {
    req.log.error({ err: error, guildId: params.data.guildId }, "Unable to update guild configuration");
    res.status(403).json({ error: error instanceof Error ? error.message : "Server access denied" });
  }
});

router.get("/discord/guilds/:guildId/stats", async (req, res): Promise<void> => {
  const params = GetGuildStatsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  try {
    const guild = await ensureGuildAccess(req, params.data.guildId);
    let config: typeof guildConfigsTable.$inferSelect | undefined;
    try {
      config = await getOrCreateConfig(params.data.guildId);
    } catch (error) {
      req.log.warn({ err: error, guildId: params.data.guildId }, "Using Discord-only stats because configuration database is unavailable");
    }
    let botOnline = false;
    let verifiedMembers = 0;
    try {
      const response = await discordBotRequest(`/guilds/${params.data.guildId}?with_counts=true`);
      botOnline = response.ok;
      if (response.ok) {
        const verified = await loadDiscordVerifiedMembers(params.data.guildId, config?.verifyRoleId);
        verifiedMembers = verified.members.length;
      }
    } catch (error) {
      req.log.warn({ err: error, guildId: params.data.guildId }, "Unable to load bot stats");
    }
    const totalMembers = guild.memberCount ?? 0;
    const pendingMembers = Math.max(totalMembers - verifiedMembers, 0);
    res.json(
      GetGuildStatsResponse.parse({
        totalMembers,
        verifiedMembers,
        pendingMembers,
        verifiedToday: 0,
        verificationRate: totalMembers ? (verifiedMembers / totalMembers) * 100 : 0,
        botOnline,
        lastSyncAt: config?.updatedAt.toISOString() ?? new Date().toISOString(),
      }),
    );
  } catch (error) {
    req.log.error({ err: error, guildId: params.data.guildId }, "Unable to load guild stats");
    res.status(403).json({ error: error instanceof Error ? error.message : "Server access denied" });
  }
});

router.get("/discord/guilds/:guildId/activity", async (req, res): Promise<void> => {
  const params = GetGuildActivityParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  try {
    await ensureGuildAccess(req, params.data.guildId);
    const activity = await db
      .select()
      .from(guildActivityTable)
      .where(eq(guildActivityTable.guildId, params.data.guildId))
      .orderBy(desc(guildActivityTable.createdAt))
      .limit(20);
    res.json(GetGuildActivityResponse.parse(activity.map(activityResponse)));
  } catch (error) {
    req.log.error({ err: error, guildId: params.data.guildId }, "Unable to load guild activity");
    res.status(403).json({ error: error instanceof Error ? error.message : "Server access denied" });
  }
});

router.post("/discord/guilds/:guildId/sync", async (req, res): Promise<void> => {
  const params = SyncGuildParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  try {
    await ensureGuildAccess(req, params.data.guildId);
    const config = await getOrCreateConfig(params.data.guildId);
    if (!config.verifyChannelId) {
      res.status(400).json({ error: "Bitte zuerst einen Verify-Kanal konfigurieren." });
      return;
    }
    const response = await discordBotRequest(`/channels/${config.verifyChannelId}/messages`, {
      method: "POST",
      body: JSON.stringify({
        content: config.verifyMessage,
        components: [
          {
            type: 1,
            components: [
              {
                type: 2,
                style: 1,
                label: config.buttonLabel,
                custom_id: "discord_verify",
              },
            ],
          },
        ],
      }),
    });
    if (!response.ok) {
      req.log.warn({ status: response.status, guildId: params.data.guildId }, "Discord rejected verify message");
      res.status(502).json({ error: "Discord konnte die Verify-Nachricht nicht senden." });
      return;
    }
    const syncedAt = new Date().toISOString();
    await db.insert(guildActivityTable).values({
      guildId: params.data.guildId,
      type: "synced",
      title: "Verify-Nachricht veröffentlicht",
      description: "Die aktuelle Verify-Nachricht wurde in Discord veröffentlicht.",
      actor: "Dashboard",
    });
    res.json(
      SyncGuildResponse.parse({
        success: true,
        message: "Verify-Nachricht wurde in Discord veröffentlicht.",
        syncedAt,
      }),
    );
  } catch (error) {
    req.log.error({ err: error, guildId: params.data.guildId }, "Unable to sync guild");
    res.status(403).json({ error: error instanceof Error ? error.message : "Server access denied" });
  }
});

type GuildMemberResponse = {
  guildId: string;
  userId: string;
  username: string;
  avatar: string | null;
  verifiedAt: string;
  lastSeenAt: string;
  leftAt: string | null;
  nextReinviteAt: string | null;
  inviteCount: number;
  status: "active" | "left" | "invite_pending";
};

function verifiedMemberResponse(member: typeof guildMembersTable.$inferSelect): GuildMemberResponse {
  return {
    guildId: member.guildId,
    userId: member.userId,
    username: member.username,
    avatar: member.avatar,
    verifiedAt: member.verifiedAt.toISOString(),
    lastSeenAt: member.lastSeenAt.toISOString(),
    leftAt: member.leftAt?.toISOString() ?? null,
    nextReinviteAt: member.nextReinviteAt?.toISOString() ?? null,
    inviteCount: member.inviteCount,
    status: member.leftAt ? (member.nextReinviteAt ? "invite_pending" : "left") : "active",
  };
}

router.get("/discord/guilds/:guildId/members", async (req, res): Promise<void> => {
  const params = GetGuildMembersParams.safeParse(req.params);
  const query = GetGuildMembersQueryParams.safeParse(req.query);
  if (!params.success || !query.success) {
    res.status(400).json({ error: "Ungültige Server- oder Limit-Angabe." });
    return;
  }
  try {
    await ensureGuildAccess(req, params.data.guildId);
    let storedMembers: Array<typeof guildMembersTable.$inferSelect> = [];
    try {
      storedMembers = await db
        .select()
        .from(guildMembersTable)
        .where(eq(guildMembersTable.guildId, params.data.guildId))
        .orderBy(desc(guildMembersTable.lastSeenAt))
        .limit(query.data.limit ?? 50);
    } catch (error) {
      req.log.warn({ err: error, guildId: params.data.guildId }, "Using Discord-only verified members because database is unavailable");
    }
    const discordMembers = await loadDiscordVerifiedMembers(params.data.guildId);
    const responses = discordMembers.members.map((member) =>
      discordVerifiedMemberResponse(params.data.guildId, member),
    );
    const knownUserIds = new Set(responses.map((member) => member.userId));
    responses.push(
      ...storedMembers
        .filter((member) => !knownUserIds.has(member.userId))
        .map(verifiedMemberResponse),
    );
    res.json(GetGuildMembersResponse.parse(responses.slice(0, query.data.limit ?? 50)));
  } catch (error) {
    req.log.error({ err: error, guildId: params.data.guildId }, "Unable to load guild members");
    res.status(403).json({ error: error instanceof Error ? error.message : "Server access denied" });
  }
});

router.get("/discord/verified-members", async (req, res): Promise<void> => {
  if (!requireDashboardAccess(req, res)) return;
  const query = GetVerifiedMembersQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: "Ungültige Limit-Angabe." });
    return;
  }
  try {
    const botGuilds = getBotGuilds();
    const requestedGuildIds = query.data.guildIds === undefined
      ? null
      : [...new Set(query.data.guildIds.split(",").map((id) => id.trim()).filter(Boolean))];
    if (requestedGuildIds?.some((id) => !botGuilds.some((guild) => guild.id === id))) {
      res.status(400).json({ error: "Die Auswahl enthält einen Server, auf dem der Bot nicht ist." });
      return;
    }
    const accessibleGuilds = requestedGuildIds === null
      ? botGuilds
      : botGuilds.filter((guild) => requestedGuildIds.includes(guild.id));
    if (!accessibleGuilds.length) {
      res.json(GetVerifiedMembersResponse.parse([]));
      return;
    }
    const guildNames = new Map(accessibleGuilds.map((guild) => [guild.id, guild.name]));
    let rows: Array<typeof guildMembersTable.$inferSelect> = [];
    try {
      rows = await db
        .select()
        .from(guildMembersTable)
        .where(inArray(guildMembersTable.guildId, accessibleGuilds.map((guild) => guild.id)))
        .orderBy(desc(guildMembersTable.verifiedAt))
        .limit(1000);
    } catch (error) {
      req.log.warn({ err: error }, "Using Discord-only verified member pool because database is unavailable");
    }
    const members = new Map<string, { userId: string; username: string; avatar: string | null; verifiedAt: string; verifiedAtEstimated: boolean; knownGuilds: number; activeGuilds: number; guilds: Array<{ id: string; name: string; active: boolean }> }>();
    const addMemberGuild = (
      userId: string,
      username: string,
      avatar: string | null,
      verifiedAt: string,
      verifiedAtEstimated: boolean,
      guildId: string,
      active: boolean,
    ) => {
      const guildName = guildNames.get(guildId);
      const current = members.get(userId);
      if (!current) {
        members.set(userId, {
          userId,
          username,
          avatar,
          verifiedAt,
          verifiedAtEstimated,
          knownGuilds: 1,
          activeGuilds: active ? 1 : 0,
          guilds: guildName ? [{ id: guildId, name: guildName, active }] : [],
        });
        return;
      }
      if (
        verifiedAt
        && (
          (current.verifiedAtEstimated && !verifiedAtEstimated)
          || (current.verifiedAtEstimated === verifiedAtEstimated && (!current.verifiedAt || verifiedAt < current.verifiedAt))
        )
      ) {
        current.verifiedAt = verifiedAt;
        current.verifiedAtEstimated = verifiedAtEstimated;
      }
      const knownGuild = current.guilds.some((guild) => guild.id === guildId);
      if (!knownGuild) {
        current.knownGuilds += 1;
        if (active) current.activeGuilds += 1;
        if (guildName) current.guilds.push({ id: guildId, name: guildName, active });
      } else if (active) {
        const currentGuild = current.guilds.find((guild) => guild.id === guildId);
        if (currentGuild && !currentGuild.active) {
          currentGuild.active = true;
          current.activeGuilds += 1;
        }
      }
    };
    for (const row of rows) {
      addMemberGuild(
        row.userId,
        row.username,
        row.avatar,
        row.verifiedAt.toISOString(),
        false,
        row.guildId,
        !row.leftAt,
      );
    }
    const discordGuildMembers = await Promise.all(
      accessibleGuilds.map(async (guild) => ({
        guildId: guild.id,
        verified: await loadDiscordVerifiedMembers(guild.id),
      })),
    );
    for (const { guildId, verified } of discordGuildMembers) {
      for (const member of verified.members) {
        const response = discordVerifiedMemberResponse(guildId, member);
        addMemberGuild(
          response.userId,
          response.username,
          response.avatar,
          response.verifiedAt,
          true,
          guildId,
          true,
        );
      }
    }
    const sortedMembers = [...members.values()]
      .sort((left, right) => right.verifiedAt.localeCompare(left.verifiedAt))
      .slice(0, query.data.limit ?? 50);
    res.json(GetVerifiedMembersResponse.parse(sortedMembers));
  } catch (error) {
    req.log.error({ err: error }, "Unable to load verified member pool");
    res.status(500).json({ error: "Verifizierte Mitglieder konnten nicht geladen werden." });
  }
});

router.post("/discord/guilds/:guildId/reinvite", async (req, res): Promise<void> => {
  const params = ReinviteGuildMembersParams.safeParse(req.params);
  const body = ReinviteGuildMembersBody.safeParse(req.body);
  if (!params.success || !body.success) {
    res.status(400).json({ error: "Bitte eine Anzahl zwischen 1 und 100 auswählen." });
    return;
  }
  try {
    await ensureGuildAccess(req, params.data.guildId);
    const config = await getOrCreateConfig(params.data.guildId);
    if (!config.verifyChannelId) {
      res.status(400).json({ error: "Für Einladungen muss zuerst ein Verify-Kanal konfiguriert werden." });
      return;
    }
    const targetMembers = await db
      .select()
      .from(guildMembersTable)
      .where(and(eq(guildMembersTable.guildId, params.data.guildId), isNull(guildMembersTable.leftAt)));
    const activeTargetIds = new Set(targetMembers.map((member) => member.userId));
    const allRows = await db
      .select()
      .from(guildMembersTable)
      .orderBy(desc(guildMembersTable.verifiedAt))
      .limit(1000);
    const selected = [];
    const seen = new Set<string>();
    for (const row of allRows) {
      if (seen.has(row.userId) || activeTargetIds.has(row.userId)) continue;
      seen.add(row.userId);
      selected.push(row);
      if (selected.length >= body.data.limit) break;
    }
    if (!selected.length) {
      res.json(ReinviteGuildMembersResponse.parse({
        success: true,
        targetGuildId: params.data.guildId,
        selected: 0,
        sent: 0,
        skipped: 0,
        message: "Für diesen Server sind aktuell keine neuen verifizierten Mitglieder verfügbar.",
      }));
      return;
    }
    const inviteResponse = await discordBotRequest(`/channels/${config.verifyChannelId}/invites`, {
      method: "POST",
      body: JSON.stringify({ max_age: 86400, max_uses: selected.length, unique: true }),
    });
    if (!inviteResponse.ok) {
      res.status(502).json({ error: "Discord konnte keine Server-Einladung erstellen." });
      return;
    }
    const invite = (await inviteResponse.json()) as { code?: string };
    if (!invite.code) {
      res.status(502).json({ error: "Discord hat keinen gültigen Einladungslink zurückgegeben." });
      return;
    }
    const results = await Promise.allSettled(selected.map(async (member) => {
      const dm = await discordBotRequest("/users/@me/channels", {
        method: "POST",
        body: JSON.stringify({ recipient_id: member.userId }),
      });
      if (!dm.ok) throw new Error(`DM channel failed: ${dm.status}`);
      const channel = (await dm.json()) as { id?: string };
      if (!channel.id) throw new Error("DM channel missing");
      const message = await discordBotRequest(`/channels/${channel.id}/messages`, {
        method: "POST",
        body: JSON.stringify({
          content: `Du bist bereits für Verifyline verifiziert. Hier ist deine Einladung für den Server: https://discord.gg/${invite.code}`,
        }),
      });
      if (!message.ok) throw new Error(`DM failed: ${message.status}`);
    }));
    const sent = results.filter((result) => result.status === "fulfilled").length;
    await db.insert(guildActivityTable).values({
      guildId: params.data.guildId,
      type: sent ? "synced" : "warning",
      title: "Verifizierte Mitglieder eingeladen",
      description: `${sent} von ${selected.length} ausgewählten Mitgliedern erhielten eine persönliche Einladung.`,
      actor: "Dashboard",
    });
    res.json(ReinviteGuildMembersResponse.parse({
      success: true,
      targetGuildId: params.data.guildId,
      selected: selected.length,
      sent,
      skipped: selected.length - sent,
      message: `${sent} persönliche Einladung${sent === 1 ? "" : "en"} versendet. Discord entscheidet, ob Direktnachrichten zugestellt werden können.`,
    }));
  } catch (error) {
    req.log.error({ err: error, guildId: params.data.guildId }, "Unable to send reinvites");
    res.status(403).json({ error: error instanceof Error ? error.message : "Server access denied" });
  }
});

export default router;