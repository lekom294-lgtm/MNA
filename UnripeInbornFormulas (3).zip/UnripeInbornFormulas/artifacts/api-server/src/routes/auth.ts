import { Router, type IRouter, type Request } from "express";
import {
  authStatus,
  clearDiscordSession,
  consumeOAuthState,
  createDiscordSession,
  createOAuthState,
  dashboardPasswordConfigured,
  getDiscordSession,
  DASHBOARD_SESSION_TTL_MS,
  hasPasswordGate,
  setPasswordGate,
  verifyPassword,
} from "../lib/auth";

const router: IRouter = Router();

function callbackUrl(req: Request): string {
  const protocol = String(req.get("x-forwarded-proto") ?? req.protocol).split(",")[0].trim();
  const forwardedHost = req.get("x-forwarded-host")?.split(",")[0].trim();
  const host = forwardedHost || req.get("host");
  if (!host) {
    throw new Error("OAuth callback host is unavailable");
  }
  return `${protocol}://${host}/api/auth/discord/callback`;
}

router.get("/auth/status", (req, res) => {
  res.json(authStatus(req));
});

router.post("/auth/password", (req, res) => {
  if (!dashboardPasswordConfigured()) {
    res.status(503).json({ error: "Dashboard password is not configured." });
    return;
  }
  if (!verifyPassword(req.body?.password)) {
    res.status(401).json({ error: "Das Passwort ist nicht korrekt." });
    return;
  }
  setPasswordGate(res);
  res.json({ ...authStatus(req), passwordPassed: true });
});

router.get("/auth/discord/start", (req, res) => {
  if (!hasPasswordGate(req)) {
    res.status(403).json({ error: "Bitte zuerst das Dashboard-Passwort eingeben." });
    return;
  }
  const clientId = process.env.DISCORD_CLIENT_ID;
  if (!clientId || !process.env.DISCORD_CLIENT_SECRET) {
    res.status(503).json({ error: "Discord OAuth ist noch nicht konfiguriert." });
    return;
  }
  const requestedReturnTo = typeof req.query.returnTo === "string" ? req.query.returnTo : "/";
  const returnTo = requestedReturnTo.startsWith("/") && !requestedReturnTo.startsWith("//") ? requestedReturnTo : "/";
  const state = createOAuthState(res, returnTo);
  const redirectUri = callbackUrl(req);
  req.log.info({ redirectUri }, "Starting Discord OAuth flow");
  const params = new URLSearchParams({
    client_id: clientId,
    response_type: "code",
    redirect_uri: redirectUri,
    scope: "identify guilds",
    state,
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});

router.get("/auth/discord/install", (req, res) => {
  if (!hasPasswordGate(req) || !getDiscordSession(req)) {
    res.status(403).send("Bitte zuerst mit deinem Discord-Konto im Dashboard anmelden.");
    return;
  }
  const clientId = process.env.DISCORD_CLIENT_ID;
  if (!clientId || !process.env.DISCORD_CLIENT_SECRET) {
    res.status(503).send("Discord-Bot-Einladung ist noch nicht konfiguriert.");
    return;
  }

  const state = createOAuthState(res, "/");
  const params = new URLSearchParams({
    client_id: clientId,
    response_type: "code",
    redirect_uri: callbackUrl(req),
    scope: "identify guilds bot applications.commands",
    state,
    prompt: "consent",
    integration_type: "0",
    permissions: "8",
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});

router.get("/auth/discord/callback", async (req, res): Promise<void> => {
  const returnTo = consumeOAuthState(req, res, typeof req.query.state === "string" ? req.query.state : "");
  if (!returnTo) {
    res.status(400).send("Discord-Anmeldung konnte nicht validiert werden.");
    return;
  }
  if (typeof req.query.error === "string") {
    res.status(400).send("Die Discord-Autorisierung wurde abgebrochen. Prüfe, ob du den Server verwalten darfst, und bestätige die angeforderten Bot-Rechte.");
    return;
  }
  const clientId = process.env.DISCORD_CLIENT_ID;
  const clientSecret = process.env.DISCORD_CLIENT_SECRET;
  const code = typeof req.query.code === "string" ? req.query.code : null;
  if (!clientId || !clientSecret || !code) {
    res.status(400).send("Discord-Anmeldung ist unvollständig.");
    return;
  }

  try {
    const tokenResponse = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: "authorization_code",
        code,
        redirect_uri: callbackUrl(req),
      }),
    });
    if (!tokenResponse.ok) {
      res.status(502).send("Discord konnte die Anmeldung nicht bestätigen.");
      return;
    }
    const token = (await tokenResponse.json()) as { access_token?: string; expires_in?: number };
    if (!token.access_token) {
      res.status(502).send("Discord hat kein gültiges Sitzungstoken geliefert.");
      return;
    }
    const userResponse = await fetch("https://discord.com/api/v10/users/@me", {
      headers: { Authorization: `Bearer ${token.access_token}` },
    });
    if (!userResponse.ok) {
      res.status(502).send("Discord-Profil konnte nicht geladen werden.");
      return;
    }
    const user = (await userResponse.json()) as {
      id: string;
      username: string;
      global_name?: string | null;
      avatar?: string | null;
    };
    createDiscordSession(res, {
      accessToken: token.access_token,
      expiresAt: Date.now() + Math.min((token.expires_in ?? 604800) * 1000, DASHBOARD_SESSION_TTL_MS),
      user: {
        id: user.id,
        username: user.username,
        globalName: user.global_name ?? null,
        avatar: user.avatar ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128` : null,
      },
    });
    res.redirect(returnTo);
  } catch (error) {
    req.log.error({ err: error }, "Discord OAuth callback failed");
    res.status(502).send("Discord-Anmeldung ist momentan nicht verfügbar.");
  }
});

router.post("/auth/logout", (req, res) => {
  clearDiscordSession(req, res);
  res.clearCookie("verifyline_gate", { path: "/" });
  res.json({ success: true });
});

export default router;