import crypto from "node:crypto";
import type { Request, Response } from "express";

const GATE_COOKIE = "verifyline_gate";
const SESSION_COOKIE = "verifyline_session";
const STATE_COOKIE = "verifyline_oauth_state";
const RETURN_TO_COOKIE = "verifyline_return_to";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7;
export const DASHBOARD_SESSION_TTL_MS = SESSION_TTL_MS;

type DiscordSession = {
  accessToken: string;
  expiresAt: number;
  user: {
    id: string;
    username: string;
    globalName: string | null;
    avatar: string | null;
  };
};

const sessions = new Map<string, DiscordSession>();

function secret(): string {
  const value = process.env.SESSION_SECRET;
  if (!value) throw new Error("SESSION_SECRET is not configured");
  return value;
}

function sign(value: string): string {
  return crypto.createHmac("sha256", secret()).update(value).digest("base64url");
}

function signedValue(value: string): string {
  return `${value}.${sign(value)}`;
}

function readSignedCookie(req: Request, name: string): string | null {
  const value = req.cookies?.[name];
  if (typeof value !== "string") return null;
  const separator = value.lastIndexOf(".");
  if (separator < 1) return null;
  const payload = value.slice(0, separator);
  const signature = value.slice(separator + 1);
  const expected = sign(payload);
  if (signature.length !== expected.length) return null;
  return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected)) ? payload : null;
}

function cookieOptions(maxAge: number) {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax" as const,
    maxAge,
    path: "/",
  };
}

export function dashboardPasswordConfigured(): boolean {
  return Boolean(process.env.DASHBOARD_PASSWORD);
}

export function hasPasswordGate(req: Request): boolean {
  return readSignedCookie(req, GATE_COOKIE) === "passed";
}

export function hasDiscordSession(req: Request): boolean {
  const sessionId = readSignedCookie(req, SESSION_COOKIE);
  if (!sessionId) return false;
  const session = sessions.get(sessionId);
  if (!session || session.expiresAt <= Date.now()) {
    sessions.delete(sessionId);
    return false;
  }
  return true;
}

export function getDiscordSession(req: Request): DiscordSession | null {
  const sessionId = readSignedCookie(req, SESSION_COOKIE);
  if (!sessionId) return null;
  const session = sessions.get(sessionId);
  if (!session || session.expiresAt <= Date.now()) {
    sessions.delete(sessionId);
    return null;
  }
  return session;
}

export function verifyPassword(password: unknown): boolean {
  const expected = process.env.DASHBOARD_PASSWORD;
  if (!expected || typeof password !== "string") return false;
  const actualBuffer = Buffer.from(password);
  const expectedBuffer = Buffer.from(expected);
  return actualBuffer.length === expectedBuffer.length && crypto.timingSafeEqual(actualBuffer, expectedBuffer);
}

export function setPasswordGate(res: Response): void {
  res.cookie(GATE_COOKIE, signedValue("passed"), cookieOptions(SESSION_TTL_MS));
}

export function createOAuthState(res: Response, returnTo: string): string {
  const state = crypto.randomBytes(24).toString("base64url");
  res.cookie(STATE_COOKIE, signedValue(state), cookieOptions(10 * 60 * 1000));
  res.cookie(RETURN_TO_COOKIE, signedValue(returnTo), cookieOptions(10 * 60 * 1000));
  return state;
}

export function consumeOAuthState(req: Request, res: Response, state: string): string | null {
  const expected = readSignedCookie(req, STATE_COOKIE);
  if (!expected || expected !== state) return null;
  const returnTo = readSignedCookie(req, RETURN_TO_COOKIE) ?? "/";
  res.clearCookie(STATE_COOKIE, { path: "/" });
  res.clearCookie(RETURN_TO_COOKIE, { path: "/" });
  return returnTo.startsWith("/") && !returnTo.startsWith("//") ? returnTo : "/";
}

export function createDiscordSession(res: Response, session: DiscordSession): void {
  const sessionId = crypto.randomBytes(32).toString("base64url");
  sessions.set(sessionId, session);
  res.cookie(SESSION_COOKIE, signedValue(sessionId), cookieOptions(SESSION_TTL_MS));
}

export function clearDiscordSession(req: Request, res: Response): void {
  const sessionId = readSignedCookie(req, SESSION_COOKIE);
  if (sessionId) sessions.delete(sessionId);
  res.clearCookie(SESSION_COOKIE, { path: "/" });
}

export function authStatus(req: Request) {
  const session = getDiscordSession(req);
  return {
    passwordConfigured: dashboardPasswordConfigured(),
    passwordPassed: hasPasswordGate(req),
    discordConfigured: Boolean(process.env.DISCORD_CLIENT_ID && process.env.DISCORD_CLIENT_SECRET),
    discordAuthenticated: Boolean(session),
    user: session?.user ?? null,
  };
}