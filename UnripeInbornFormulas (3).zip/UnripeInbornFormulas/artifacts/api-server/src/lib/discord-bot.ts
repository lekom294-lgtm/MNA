import { db, guildActivityTable, guildConfigsTable, guildMembersTable } from "@workspace/db";
import { and, eq, isNull, lte, sql } from "drizzle-orm";
import { logger } from "./logger";

const DISCORD_API = "https://discord.com/api/v10";
const GUILDS_INTENT = 1;
const GUILD_MEMBERS_INTENT = 2;
const DISCORD_PERMISSIONS = {
  administrator: 1n << 3n,
  manageChannels: 1n << 4n,
  manageRoles: 1n << 28n,
  viewChannel: 1n << 10n,
  sendMessages: 1n << 11n,
  embedLinks: 1n << 14n,
  readMessageHistory: 1n << 16n,
} as const;

type GatewayEvent = {
  data: string | ArrayBuffer | Blob;
};

type GatewaySocket = {
  addEventListener: (type: "open" | "message" | "close" | "error", listener: (event: GatewayEvent | { code?: number }) => void) => void;
  send: (payload: string) => void;
  close: () => void;
};

type GatewayPayload = {
  op: number;
  d: Record<string, unknown> | null;
  t?: string;
};

type DiscordRole = {
  id: string;
  name: string;
  position: number;
  permissions: string;
  managed?: boolean;
};

type DiscordChannel = {
  id: string;
  name?: string;
  type?: number;
};

type DiscordMessage = {
  id: string;
  author?: { id?: string };
  components?: Array<{
    components?: Array<{ custom_id?: string }>;
  }>;
};

type SetupContext = {
  roles: DiscordRole[];
  botRoleId: string | null;
  highestRolePosition: number;
  permissions: bigint;
};

export type ConnectedBotGuild = {
  id: string;
  name: string;
  icon: string | null;
  memberCount: number | null;
};

const connectedBotGuilds = new Map<string, ConnectedBotGuild>();

export function getConnectedBotGuilds(): ConnectedBotGuild[] {
  return [...connectedBotGuilds.values()].sort((left, right) => left.name.localeCompare(right.name));
}

function rememberConnectedGuild(data: Record<string, unknown>): void {
  if (typeof data.id !== "string" || typeof data.name !== "string") return;
  connectedBotGuilds.set(data.id, {
    id: data.id,
    name: data.name,
    icon: typeof data.icon === "string" ? data.icon : null,
    memberCount: typeof data.member_count === "number" ? data.member_count : null,
  });
}

async function botRequest(path: string, init: RequestInit = {}): Promise<Response> {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) {
    throw new Error("DISCORD_BOT_TOKEN is not configured");
  }
  const headers = new Headers(init.headers);
  headers.set("Authorization", `Bot ${token}`);
  headers.set("Content-Type", "application/json");
  return fetch(`${DISCORD_API}${path}`, { ...init, headers });
}

async function interactionCallback(
  interactionId: string,
  interactionToken: string,
  body: Record<string, unknown>,
): Promise<void> {
  const response = await fetch(`${DISCORD_API}/interactions/${interactionId}/${interactionToken}/callback`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    throw new Error(`Discord interaction callback failed: ${response.status} ${await response.text()}`);
  }
}

async function deferInteraction(interactionId: string, interactionToken: string): Promise<boolean> {
  try {
    await interactionCallback(interactionId, interactionToken, {
      type: 5,
      data: { flags: 64 },
    });
    return true;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes("10062") || message.includes("40060")) {
      logger.warn({ interactionId, message }, "Discord interaction was already handled by another gateway session");
      return false;
    }
    throw error;
  }
}

async function followUpInteraction(
  applicationId: string,
  interactionToken: string,
  content: string,
): Promise<void> {
  const response = await fetch(`${DISCORD_API}/webhooks/${applicationId}/${interactionToken}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content, flags: 64 }),
  });
  if (!response.ok) {
    throw new Error(`Discord interaction follow-up failed: ${response.status} ${await response.text()}`);
  }
}

const applicationCommands = [
  {
    name: "setup_verify",
    description: "Erstellt den Verify-Kanal, die Verify-Rolle und den Verify-Button.",
    default_member_permissions: "8",
  },
  {
    name: "verify-status",
    description: "Zeigt den Verify-Status dieses Servers.",
  },
  {
    name: "verify-help",
    description: "Zeigt die wichtigsten Verifyline-Befehle.",
  },
  {
    name: "verify-publish",
    description: "Veröffentlicht die konfigurierte Verify-Nachricht erneut.",
    default_member_permissions: "8",
  },
];

function hasDiscordPermission(permissions: bigint, permission: bigint): boolean {
  return (permissions & (DISCORD_PERMISSIONS.administrator | permission)) !== 0n;
}

async function readDiscordSetupContext(guildId: string): Promise<SetupContext> {
  const [rolesResponse, currentUserResponse] = await Promise.all([
    botRequest(`/guilds/${guildId}/roles`),
    botRequest("/users/@me"),
  ]);
  if (!rolesResponse.ok) {
    throw new Error(`Discord konnte die Serverrollen nicht laden (${rolesResponse.status}).`);
  }
  if (!currentUserResponse.ok) {
    throw new Error(`Discord konnte den Bot-Benutzer nicht laden (${currentUserResponse.status}).`);
  }

  const roles = await rolesResponse.json() as DiscordRole[];
  const currentUser = await currentUserResponse.json() as { id?: string };
  if (!currentUser.id) {
    throw new Error("Discord hat keine Bot-Benutzer-ID zurückgegeben.");
  }

  const memberResponse = await botRequest(`/guilds/${guildId}/members/${currentUser.id}`);
  if (!memberResponse.ok) {
    throw new Error(
      memberResponse.status === 404
        ? "Der Bot ist nicht Mitglied dieses Servers."
        : `Discord konnte die Bot-Berechtigungen nicht laden (${memberResponse.status}).`,
    );
  }
  const member = await memberResponse.json() as { roles?: string[] };
  const memberRoleIds = new Set(member.roles ?? []);
  const memberRoles = roles.filter((role) => memberRoleIds.has(role.id));
  const permissions = roles
    .filter((role) => role.id === guildId || memberRoleIds.has(role.id))
    .reduce((total, role) => total | BigInt(role.permissions || "0"), 0n);
  const highestRole = memberRoles
    .filter((role) => role.id !== guildId)
    .sort((left, right) => right.position - left.position)[0];

  return {
    roles,
    botRoleId: highestRole?.id ?? null,
    highestRolePosition: highestRole?.position ?? 0,
    permissions,
  };
}

async function ensureVerifyRole(
  guildId: string,
  configuredRoleId: string | null | undefined,
  context: SetupContext,
): Promise<{ role: DiscordRole; created: boolean }> {
  const existingRole = context.roles.find((role) =>
    !role.managed && (
      role.id === configuredRoleId
      || ["verified", "verifiziert", "verify"].includes(role.name.trim().toLowerCase())
    ),
  );
  if (existingRole) {
    return { role: existingRole, created: false };
  }

  const response = await botRequest(`/guilds/${guildId}/roles`, {
    method: "POST",
    body: JSON.stringify({
      name: "Verified",
      color: 0x5865f2,
      hoist: false,
      mentionable: false,
      reason: "Verifyline automatische Einrichtung",
    }),
  });
  if (!response.ok) {
    throw new Error(
      response.status === 403
        ? "Der Bot darf keine Rollen verwalten. Gib ihm auf dem Server die Berechtigung „Rollen verwalten“ und führe /setup_verify erneut aus."
        : `Discord konnte die Verify-Rolle nicht erstellen (${response.status}).`,
    );
  }
  const role = await response.json() as DiscordRole;
  if (!role.id) {
    throw new Error("Discord hat keine ID für die neue Verify-Rolle zurückgegeben.");
  }
  return { role, created: true };
}

async function ensureVerifyChannel(
  guildId: string,
  configuredChannelId: string | null | undefined,
  botRoleId: string | null,
): Promise<{ channel: DiscordChannel; created: boolean }> {
  let channel: DiscordChannel | undefined;
  if (configuredChannelId) {
    const response = await botRequest(`/channels/${configuredChannelId}`);
    if (response.ok) {
      const configured = await response.json() as DiscordChannel;
      if (configured.id && configured.type === 0) {
        channel = configured;
      }
    }
  }

  if (!channel) {
    const response = await botRequest(`/guilds/${guildId}/channels`);
    if (!response.ok) {
      throw new Error(`Discord konnte die vorhandenen Kanäle nicht laden (${response.status}).`);
    }
    const channels = await response.json() as DiscordChannel[];
    channel = channels.find((item) =>
      item.type === 0 && ["verify", "verifyline", "verifizierung"].includes((item.name ?? "").toLowerCase()),
    );
  }

  let created = false;
  if (!channel) {
    const allowEveryone = DISCORD_PERMISSIONS.viewChannel | DISCORD_PERMISSIONS.readMessageHistory;
    const allowBot = allowEveryone
      | DISCORD_PERMISSIONS.sendMessages
      | DISCORD_PERMISSIONS.embedLinks;
    const response = await botRequest(`/guilds/${guildId}/channels`, {
      method: "POST",
      body: JSON.stringify({
        name: "verify",
        type: 0,
        topic: "Verifyline – klicke auf den Button, um dich zu verifizieren.",
        permission_overwrites: [
          {
            id: guildId,
            type: 0,
            allow: String(allowEveryone),
            deny: String(DISCORD_PERMISSIONS.sendMessages),
          },
          ...(botRoleId ? [{
            id: botRoleId,
            type: 0,
            allow: String(allowBot),
            deny: "0",
          }] : []),
        ],
        reason: "Verifyline automatische Einrichtung",
      }),
    });
    if (!response.ok) {
      throw new Error(
        response.status === 403
          ? "Der Bot darf keinen Kanal erstellen. Gib ihm auf dem Server die Berechtigung „Kanäle verwalten“ und führe /setup_verify erneut aus."
          : `Discord konnte den Verify-Kanal nicht erstellen (${response.status}).`,
      );
    }
    channel = await response.json() as DiscordChannel;
    created = true;
  }

  if (!channel.id) {
    throw new Error("Discord hat keine ID für den Verify-Kanal zurückgegeben.");
  }
  if (botRoleId) {
    const allowBot = DISCORD_PERMISSIONS.viewChannel
      | DISCORD_PERMISSIONS.sendMessages
      | DISCORD_PERMISSIONS.embedLinks
      | DISCORD_PERMISSIONS.readMessageHistory;
    const permissionResponse = await botRequest(`/channels/${channel.id}/permissions/${botRoleId}`, {
      method: "PUT",
      body: JSON.stringify({ type: 0, allow: String(allowBot), deny: "0" }),
    });
    if (!permissionResponse.ok && permissionResponse.status === 403) {
      throw new Error("Der Bot kann den Verify-Kanal nicht bearbeiten. Gib ihm die Berechtigung „Kanäle verwalten“.");
    }
  }
  return { channel, created };
}

async function findExistingVerifyChannel(
  guildId: string,
  configuredChannelId: string | null | undefined,
): Promise<DiscordChannel | undefined> {
  if (configuredChannelId) {
    const configuredResponse = await botRequest(`/channels/${configuredChannelId}`);
    if (configuredResponse.ok) {
      const configured = await configuredResponse.json() as DiscordChannel;
      if (configured.id && configured.type === 0) return configured;
    }
  }
  const response = await botRequest(`/guilds/${guildId}/channels`);
  if (!response.ok) return undefined;
  const channels = await response.json() as DiscordChannel[];
  return channels.find((item) =>
    item.type === 0 && ["verify", "verifyline", "verifizierung"].includes((item.name ?? "").toLowerCase()),
  );
}

async function findExistingVerifyRole(
  guildId: string,
  configuredRoleId: string | null | undefined,
): Promise<DiscordRole | undefined> {
  const response = await botRequest(`/guilds/${guildId}/roles`);
  if (!response.ok) return undefined;
  const roles = await response.json() as DiscordRole[];
  return roles.find((role) =>
    !role.managed && (
      role.id === configuredRoleId
      || ["verified", "verifiziert", "verify"].includes(role.name.trim().toLowerCase())
    ),
  );
}

async function publishVerifyMessage(
  channelId: string,
  roleId: string,
  verifyMessage: string,
  buttonLabel: string,
): Promise<"created" | "updated"> {
  const [currentUserResponse, messagesResponse] = await Promise.all([
    botRequest("/users/@me"),
    botRequest(`/channels/${channelId}/messages?limit=100`),
  ]);
  if (!currentUserResponse.ok || !messagesResponse.ok) {
    const failedStatus = !messagesResponse.ok ? messagesResponse.status : currentUserResponse.status;
    throw new Error(
      messagesResponse.status === 403
        ? "Der Bot darf die Verify-Nachrichten nicht lesen. Prüfe die Kanalrechte „Nachrichtenverlauf lesen“."
        : `Discord konnte die bestehende Verify-Nachricht nicht prüfen (${failedStatus}).`,
    );
  }
  const currentUser = await currentUserResponse.json() as { id?: string };
  const messages = await messagesResponse.json() as DiscordMessage[];
  const existingMessage = currentUser.id
    ? messages.find((message) =>
      message.author?.id === currentUser.id
      && message.components?.some((row) =>
        row.components?.some((component) => component.custom_id?.startsWith("discord_verify")),
      ),
    )
    : undefined;
  const body = JSON.stringify({
    content: verifyMessage,
    components: [{
      type: 1,
      components: [{
        type: 2,
        style: 1,
        label: buttonLabel,
        custom_id: `discord_verify:${roleId}`,
      }],
    }],
  });
  const response = await botRequest(
    existingMessage
      ? `/channels/${channelId}/messages/${existingMessage.id}`
      : `/channels/${channelId}/messages`,
    {
    method: existingMessage ? "PATCH" : "POST",
    body,
  });
  if (!response.ok) {
    throw new Error(
      response.status === 403
        ? "Der Bot darf im Verify-Kanal keine Nachrichten senden. Prüfe die Kanalrechte."
        : `Discord konnte den Verify-Button nicht veröffentlichen (${response.status}).`,
    );
  }
  return existingMessage ? "updated" : "created";
}

async function runVerifySetup(guildId: string): Promise<{
  channelName: string;
  roleName: string;
  channelCreated: boolean;
  roleCreated: boolean;
  messageAction: "created" | "updated";
  databasePersisted: boolean;
}> {
  let config: typeof guildConfigsTable.$inferSelect | undefined;
  let databasePersisted = false;
  try {
    [config] = await db.select().from(guildConfigsTable).where(eq(guildConfigsTable.guildId, guildId));
  } catch (error) {
    logger.warn({ err: error, guildId }, "Verify setup could not read configuration");
  }

  let context = await readDiscordSetupContext(guildId);
  if (!hasDiscordPermission(context.permissions, DISCORD_PERMISSIONS.manageChannels)) {
    throw new Error("Der Bot benötigt die Discord-Berechtigung „Kanäle verwalten“, damit er den Verify-Kanal erstellen kann.");
  }
  if (!hasDiscordPermission(context.permissions, DISCORD_PERMISSIONS.manageRoles)) {
    throw new Error("Der Bot benötigt die Discord-Berechtigung „Rollen verwalten“, damit er die Verify-Rolle vergeben kann.");
  }

  const roleResult = await ensureVerifyRole(guildId, config?.verifyRoleId, context);
  context = await readDiscordSetupContext(guildId);
  if (roleResult.role.managed || roleResult.role.position >= context.highestRolePosition) {
    throw new Error("Die Verify-Rolle liegt über der Bot-Rolle. Verschiebe die Bot-Rolle in den Servereinstellungen über die Verify-Rolle und führe /setup_verify erneut aus.");
  }

  const channelResult = await ensureVerifyChannel(guildId, config?.verifyChannelId, context.botRoleId);
  const verifyMessage = config?.verifyMessage ?? "Klicke auf den Button, um dich zu verifizieren.";
  const buttonLabel = config?.buttonLabel ?? "Verifizieren";
  const messageAction = await publishVerifyMessage(
    channelResult.channel.id,
    roleResult.role.id,
    verifyMessage,
    buttonLabel,
  );

  try {
    await db.insert(guildConfigsTable)
      .values({
        guildId,
        enabled: true,
        verifyChannelId: channelResult.channel.id,
        verifyRoleId: roleResult.role.id,
        verifyMessage,
        buttonLabel,
        autoRoleEnabled: true,
        autoReinviteEnabled: config?.autoReinviteEnabled ?? false,
      })
      .onConflictDoUpdate({
        target: guildConfigsTable.guildId,
        set: {
          enabled: true,
          verifyChannelId: channelResult.channel.id,
          verifyRoleId: roleResult.role.id,
          autoRoleEnabled: true,
          updatedAt: new Date(),
        },
      });
    databasePersisted = true;
  } catch (error) {
    logger.warn({ err: error, guildId }, "Verify setup completed in Discord but configuration could not be saved");
  }

  if (databasePersisted) {
    try {
    await db.insert(guildActivityTable).values({
      guildId,
      type: "config_updated",
      title: "Verify automatisch eingerichtet",
      description: `Kanal #${channelResult.channel.name ?? "verify"} und Rolle ${roleResult.role.name} wurden für die Verify-Funktion eingerichtet.`,
      actor: "Verifyline Bot",
    });
    } catch (error) {
      logger.warn({ err: error, guildId }, "Verify setup activity could not be recorded");
    }
  }

  return {
    channelName: channelResult.channel.name ?? "verify",
    roleName: roleResult.role.name,
    channelCreated: channelResult.created,
    roleCreated: roleResult.created,
    messageAction,
    databasePersisted,
  };
}

async function clearGlobalApplicationCommands(applicationId: string): Promise<void> {
  const response = await botRequest(`/applications/${applicationId}/commands`, {
    method: "PUT",
    body: "[]",
  });
  if (!response.ok) {
    logger.warn({ status: response.status }, "Discord global slash commands could not be cleared");
    return;
  }
  logger.info("Discord global slash commands cleared; guild commands are authoritative");
}

async function registerApplicationCommands(applicationId: string, guildId: string): Promise<void> {
  const path = `/applications/${applicationId}/guilds/${guildId}/commands`;
  const response = await botRequest(path, {
    method: "PUT",
    body: JSON.stringify(applicationCommands),
  });
  if (!response.ok) {
    logger.warn({ status: response.status, guildId }, "Discord slash commands could not be registered");
    return;
  }
  logger.info({ guildId, count: applicationCommands.length }, "Discord slash commands registered");
}

async function handleApplicationCommand(data: Record<string, unknown>): Promise<void> {
  const command = data.data && typeof data.data === "object" ? data.data as { name?: string } : {};
  const guildId = typeof data.guild_id === "string" ? data.guild_id : null;
  const applicationId = typeof data.application_id === "string" ? data.application_id : null;
  const interactionId = typeof data.id === "string" ? data.id : null;
  const interactionToken = typeof data.token === "string" ? data.token : null;
  if (!guildId || !applicationId || !interactionId || !interactionToken || !command.name) return;

  if (!await deferInteraction(interactionId, interactionToken)) return;
  try {
    if (command.name === "verify-help") {
      await followUpInteraction(
        applicationId,
        interactionToken,
        "Verifyline: `/setup_verify` erstellt automatisch Verify-Kanal, Verify-Rolle und Button. `/verify-status` zeigt den Serverstatus, `/verify-publish` veröffentlicht den Button erneut. Mitglieder bekommen beim Klick automatisch die Verify-Rolle.",
      );
      return;
    }
    if (command.name === "setup_verify") {
      try {
        const result = await runVerifySetup(guildId);
        const created = [
          result.channelCreated ? `Kanal #${result.channelName}` : `vorhandener Kanal #${result.channelName}`,
          result.roleCreated ? `Rolle ${result.roleName}` : `vorhandene Rolle ${result.roleName}`,
        ].join(" und ");
        const messageStatus = result.messageAction === "updated"
          ? "Die vorhandene Verify-Nachricht wurde aktualisiert."
          : "Der Verify-Button wurde veröffentlicht.";
        const storageStatus = result.databasePersisted
          ? "Die Konfiguration wurde gespeichert."
          : "Die Discord-Einrichtung funktioniert bereits; Dashboard- und Statistikdaten werden gespeichert, sobald die Datenbank wieder verfügbar ist.";
        await followUpInteraction(
          applicationId,
          interactionToken,
          `Verify ist eingerichtet. ${created} wurden verwendet. ${messageStatus} Mitglieder erhalten beim Klick automatisch die Verify-Rolle. ${storageStatus}`,
        );
      } catch (error) {
        const message = error instanceof Error ? error.message : "Die Verify-Einrichtung konnte nicht abgeschlossen werden.";
        logger.warn({ err: error, guildId }, "Verify setup failed");
        await followUpInteraction(
          applicationId,
          interactionToken,
          message,
        );
      }
      return;
    }
    if (command.name === "verify-status") {
      const connectedGuild = getConnectedBotGuilds().find((guild) => guild.id === guildId);
      let memberCount = connectedGuild?.memberCount ?? null;
      try {
        const guildResponse = await botRequest(`/guilds/${guildId}?with_counts=true`);
        if (guildResponse.ok) {
          const guild = await guildResponse.json() as { approximate_member_count?: number; member_count?: number };
          memberCount = guild.approximate_member_count ?? guild.member_count ?? memberCount;
        }
      } catch (error) {
        logger.warn({ err: error, guildId }, "Discord status member count unavailable");
      }
      let config: typeof guildConfigsTable.$inferSelect | undefined;
      let configUnavailable = false;
      try {
        [config] = await db.select().from(guildConfigsTable).where(eq(guildConfigsTable.guildId, guildId));
      } catch (error) {
        configUnavailable = true;
        logger.warn({ err: error, guildId }, "Discord status configuration unavailable");
      }
      const configurationStatus = configUnavailable
        ? "Die Produktionsdatenbank ist pausiert; Verify-Konfiguration konnte nicht geladen werden."
        : config?.enabled && config.verifyChannelId && config.verifyRoleId
        ? "Verify-Konfiguration ist aktiv."
        : config
          ? "Verify-Konfiguration ist noch nicht vollständig eingerichtet."
          : "Für diesen Server wurde noch keine Verify-Konfiguration gespeichert.";
      await followUpInteraction(
        applicationId,
        interactionToken,
        `Verifyline-Status für ${connectedGuild?.name ?? "diesen Server"}: ${memberCount ?? "?"} Mitglieder. Bot ist verbunden. ${configurationStatus}`,
      );
      return;
    }
    if (command.name === "verify-publish") {
      let config: typeof guildConfigsTable.$inferSelect | undefined;
      try {
        [config] = await db.select().from(guildConfigsTable).where(eq(guildConfigsTable.guildId, guildId));
      } catch (error) {
        logger.warn({ err: error, guildId }, "Verify publish is using Discord-only fallback because the database is paused");
      }
      const channel = await findExistingVerifyChannel(guildId, config?.verifyChannelId);
      const role = await findExistingVerifyRole(guildId, config?.verifyRoleId);
      if (!channel || !role) {
        await followUpInteraction(applicationId, interactionToken, "Es wurde noch keine Verify-Einrichtung gefunden. Bitte zuerst `/setup_verify` ausführen.");
        return;
      }
      try {
        const messageAction = await publishVerifyMessage(
          channel.id,
          role.id,
          config?.verifyMessage ?? "Klicke auf den Button, um dich zu verifizieren.",
          config?.buttonLabel ?? "Verifizieren",
        );
        await followUpInteraction(
          applicationId,
          interactionToken,
          messageAction === "updated"
            ? "Die vorhandene Verify-Nachricht wurde aktualisiert. Es wurde keine zweite Nachricht erstellt."
            : "Die Verify-Nachricht wurde veröffentlicht.",
        );
      } catch (error) {
        await followUpInteraction(
          applicationId,
          interactionToken,
          error instanceof Error ? error.message : "Discord konnte die Verify-Nachricht nicht veröffentlichen.",
        );
      }
      return;
    }
  } catch (error) {
    logger.error({ err: error, guildId, command: command.name }, "Discord slash command failed");
    await followUpInteraction(
      applicationId,
      interactionToken,
      "Der Command konnte gerade nicht vollständig ausgeführt werden. Bitte prüfe die Verifyline-Konfiguration im Dashboard.",
    ).catch((followUpError) => logger.error({ err: followUpError, guildId }, "Discord slash command error response failed"));
  }
}

async function handleVerifyInteraction(data: Record<string, unknown>): Promise<void> {
  const guildId = typeof data.guild_id === "string" ? data.guild_id : null;
  const applicationId = typeof data.application_id === "string" ? data.application_id : null;
  const interactionData = data.data && typeof data.data === "object"
    ? data.data as { custom_id?: string }
    : {};
  const buttonRoleId = typeof interactionData.custom_id === "string"
    && interactionData.custom_id.startsWith("discord_verify:")
    ? interactionData.custom_id.slice("discord_verify:".length)
    : null;
  const user = data.member && typeof data.member === "object"
    ? (data.member as { user?: { id?: string; username?: string } }).user
    : undefined;
  const userId = user?.id;
  const interactionId = typeof data.id === "string" ? data.id : null;
  const interactionToken = typeof data.token === "string" ? data.token : null;
  if (!guildId || !applicationId || !userId || !interactionId || !interactionToken) {
    return;
  }

  if (!await deferInteraction(interactionId, interactionToken)) return;
  try {
    let config: typeof guildConfigsTable.$inferSelect | undefined;
    let databaseUnavailable = false;
    try {
      [config] = await db
        .select()
        .from(guildConfigsTable)
        .where(eq(guildConfigsTable.guildId, guildId));
    } catch (error) {
      databaseUnavailable = true;
      logger.warn({ err: error, guildId }, "Verification is using the Discord button role fallback because the database is paused");
    }

    if (config && (!config.enabled || !config.autoRoleEnabled || !config.verifyRoleId)) {
      await followUpInteraction(applicationId, interactionToken, "Die Verifizierung ist für diesen Server noch nicht vollständig eingerichtet.");
      return;
    }
    const roleId = config?.verifyRoleId ?? buttonRoleId ?? (await findExistingVerifyRole(guildId, null))?.id;
    if (!roleId) {
      await followUpInteraction(applicationId, interactionToken, "Die Verify-Rolle konnte nicht gefunden werden. Bitte `/setup_verify` erneut ausführen.");
      return;
    }

    const roleResponse = await botRequest(
      `/guilds/${guildId}/members/${userId}/roles/${roleId}`,
      { method: "PUT", body: "{}" },
    );
    if (!roleResponse.ok) {
      await followUpInteraction(applicationId, interactionToken, "Die Rolle konnte gerade nicht vergeben werden. Bitte versuche es gleich noch einmal.");
      logger.warn({ guildId, userId, status: roleResponse.status }, "Discord rejected verification role assignment");
      return;
    }

    try {
      await db.insert(guildActivityTable).values({
        guildId,
        type: "verified",
        title: "Mitglied verifiziert",
        description: `${user?.username ?? "Ein Mitglied"} hat die Verify-Prüfung bestanden.`,
        actor: user?.username ?? null,
      });
      await db.insert(guildMembersTable).values({
        guildId,
        userId,
        username: user?.username ?? "Discord member",
        avatar: null,
        verifiedAt: new Date(),
        lastSeenAt: new Date(),
        leftAt: null,
        nextReinviteAt: null,
        lastInviteAt: null,
        inviteCount: 0,
      }).onConflictDoUpdate({
        target: [guildMembersTable.guildId, guildMembersTable.userId],
        set: {
          username: user?.username ?? "Discord member",
          lastSeenAt: new Date(),
          leftAt: null,
          nextReinviteAt: null,
        },
      });
    } catch (error) {
      logger.warn({ err: error, guildId, userId }, "Verification role assigned but database activity could not be recorded");
    }
    await followUpInteraction(
      applicationId,
      interactionToken,
      databaseUnavailable
        ? "Du bist verifiziert. Die Rolle wurde vergeben. Die Statistik wird gespeichert, sobald die Datenbank wieder verfügbar ist."
        : "Du bist verifiziert. Willkommen auf dem Server.",
    );
  } catch (error) {
    logger.error({ err: error, guildId, userId }, "Discord verification interaction failed");
    await followUpInteraction(
      applicationId,
      interactionToken,
      "Die Verifizierung konnte gerade nicht abgeschlossen werden. Bitte versuche es erneut.",
    ).catch((followUpError) => logger.error({ err: followUpError, guildId, userId }, "Discord verification error response failed"));
  }
}

async function handleMemberAdd(data: Record<string, unknown>): Promise<void> {
  const guildId = typeof data.guild_id === "string" ? data.guild_id : null;
  const user = data.user && typeof data.user === "object" ? data.user as { id?: string; username?: string; avatar?: string | null } : null;
  if (!guildId || !user?.id) return;
  await db.update(guildMembersTable)
    .set({ lastSeenAt: new Date(), leftAt: null, nextReinviteAt: null, username: user.username ?? "Discord member", avatar: user.avatar ?? null })
    .where(and(eq(guildMembersTable.guildId, guildId), eq(guildMembersTable.userId, user.id)));
}

async function handleMemberRemove(data: Record<string, unknown>): Promise<void> {
  const guildId = typeof data.guild_id === "string" ? data.guild_id : null;
  const user = data.user && typeof data.user === "object" ? data.user as { id?: string } : null;
  if (!guildId || !user?.id) return;
  const [config] = await db.select().from(guildConfigsTable).where(eq(guildConfigsTable.guildId, guildId));
  await db.update(guildMembersTable)
    .set({
      leftAt: new Date(),
      nextReinviteAt: config?.autoReinviteEnabled ? new Date(Date.now() + 24 * 60 * 60 * 1000) : null,
    })
    .where(and(eq(guildMembersTable.guildId, guildId), eq(guildMembersTable.userId, user.id)));
}

async function sendInviteToMember(userId: string, guildId: string, channelId: string): Promise<void> {
  const inviteResponse = await botRequest(`/channels/${channelId}/invites`, {
    method: "POST",
    body: JSON.stringify({ max_age: 86400, max_uses: 1, unique: true }),
  });
  if (!inviteResponse.ok) throw new Error(`Invite creation failed: ${inviteResponse.status}`);
  const invite = (await inviteResponse.json()) as { code?: string };
  if (!invite.code) throw new Error("Discord invite response had no code");
  const dmResponse = await botRequest("/users/@me/channels", {
    method: "POST",
    body: JSON.stringify({ recipient_id: userId }),
  });
  if (!dmResponse.ok) throw new Error(`DM channel failed: ${dmResponse.status}`);
  const dm = (await dmResponse.json()) as { id?: string };
  if (!dm.id) throw new Error("Discord DM channel had no id");
  const messageResponse = await botRequest(`/channels/${dm.id}/messages`, {
    method: "POST",
    body: JSON.stringify({ content: `Du bist weiterhin für Verifyline verifiziert. Hier ist deine Einladung zurück auf den Server: https://discord.gg/${invite.code}` }),
  });
  if (!messageResponse.ok) throw new Error(`DM failed: ${messageResponse.status}`);
  await db.update(guildMembersTable)
    .set({ nextReinviteAt: null, lastInviteAt: new Date(), inviteCount: sql`${guildMembersTable.inviteCount} + 1` })
    .where(and(eq(guildMembersTable.guildId, guildId), eq(guildMembersTable.userId, userId)));
}

async function processReinviteQueue(): Promise<void> {
  const configs = await db.select().from(guildConfigsTable).where(eq(guildConfigsTable.autoReinviteEnabled, true));
  for (const config of configs) {
    if (!config.verifyChannelId) continue;
    const dueMembers = await db.select().from(guildMembersTable)
      .where(and(eq(guildMembersTable.guildId, config.guildId), lte(guildMembersTable.nextReinviteAt, new Date())))
      .limit(10);
    for (const member of dueMembers) {
      try {
        await sendInviteToMember(member.userId, config.guildId, config.verifyChannelId);
        await db.insert(guildActivityTable).values({
          guildId: config.guildId,
          type: "synced",
          title: "Automatische Wiedereinladung versendet",
          description: `${member.username} erhielt nach 24 Stunden eine neue Server-Einladung.`,
          actor: "Verifyline Bot",
        });
      } catch (error) {
        logger.warn({ err: error, guildId: config.guildId, userId: member.userId }, "Automatic reinvite failed");
      }
    }
  }
}

export function startDiscordBot(): void {
  const token = process.env.DISCORD_BOT_TOKEN;
  const WebSocketCtor = (globalThis as typeof globalThis & {
    WebSocket?: new (url: string) => GatewaySocket;
  }).WebSocket;

  if (!token || !WebSocketCtor) {
    logger.warn("Discord bot gateway is unavailable");
    return;
  }

  const connect = () => {
    const socket = new WebSocketCtor("wss://gateway.discord.gg/?v=10&encoding=json");
    let heartbeat: ReturnType<typeof setInterval> | undefined;
    let intentionalClose = false;
    let applicationId: string | undefined;
    const handlesInteractions = process.env.NODE_ENV === "production";

    socket.addEventListener("open", () => {
      logger.info("Discord bot gateway connected");
    });
    socket.addEventListener("message", (event) => {
      void (async () => {
        const raw = typeof event.data === "string" ? event.data : await new Response(event.data).text();
        const payload = JSON.parse(raw) as GatewayPayload;
        if (payload.op === 10 && payload.d) {
          const interval = Number(payload.d.heartbeat_interval);
          heartbeat = setInterval(() => socket.send(JSON.stringify({ op: 1, d: null })), interval);
          socket.send(JSON.stringify({
            op: 2,
            d: {
              token,
              intents: GUILDS_INTENT | GUILD_MEMBERS_INTENT,
              properties: { os: "linux", browser: "verifyline", device: "verifyline" },
            },
          }));
        }
        if (payload.op === 0 && payload.t === "READY" && payload.d) {
          const readyGuilds = Array.isArray(payload.d.guilds) ? payload.d.guilds : [];
          for (const guild of readyGuilds) {
            if (guild && typeof guild === "object") rememberConnectedGuild(guild as Record<string, unknown>);
          }
           applicationId = payload.d.user && typeof payload.d.user === "object"
            ? (payload.d.user as { id?: string }).id
            : undefined;
           const readyGuildIds = readyGuilds
             .filter((guild): guild is Record<string, unknown> => Boolean(guild && typeof guild === "object"))
             .map((guild) => typeof guild.id === "string" ? guild.id : null)
             .filter((guildId): guildId is string => Boolean(guildId));
           logger.info({ guildCount: readyGuildIds.length, applicationId, handlesInteractions }, "Discord bot gateway ready");
           if (applicationId && handlesInteractions) {
              await clearGlobalApplicationCommands(applicationId);
             await Promise.all(readyGuildIds.map((guildId) => registerApplicationCommands(applicationId!, guildId)));
           } else if (applicationId) {
             logger.info("Development gateway connected; slash command registration is handled by production");
           }
        }
        if (payload.op === 1) {
          socket.send(JSON.stringify({ op: 1, d: null }));
        }
        if (payload.op === 0 && payload.t === "GUILD_MEMBER_ADD" && payload.d) {
          await handleMemberAdd(payload.d);
        }
        if (payload.op === 0 && payload.t === "GUILD_MEMBER_REMOVE" && payload.d) {
          await handleMemberRemove(payload.d);
        }
        if (payload.op === 0 && (payload.t === "GUILD_CREATE" || payload.t === "GUILD_UPDATE") && payload.d) {
          rememberConnectedGuild(payload.d);
          if (payload.t === "GUILD_CREATE" && handlesInteractions && applicationId && typeof payload.d.id === "string") {
             await registerApplicationCommands(applicationId, payload.d.id);
           }
        }
        if (payload.op === 0 && payload.t === "GUILD_DELETE" && payload.d && typeof payload.d.id === "string") {
          connectedBotGuilds.delete(payload.d.id);
        }
        if (payload.op === 0 && payload.t === "INTERACTION_CREATE" && payload.d) {
           const interactionCommand = payload.d.data && typeof payload.d.data === "object"
             ? (payload.d.data as { name?: string }).name
             : undefined;
           if (!handlesInteractions) {
             logger.info({ interactionType: payload.d.type, command: interactionCommand }, "Discord interaction ignored by development gateway");
             return;
           }
           logger.info({ interactionType: payload.d.type, command: interactionCommand }, "Discord interaction received");
          if (payload.d.type === 2) {
            await handleApplicationCommand(payload.d);
            return;
          }
          const customId = payload.d.data && typeof payload.d.data === "object"
            ? (payload.d.data as { custom_id?: string }).custom_id
            : undefined;
           if (customId?.startsWith("discord_verify")) {
            await handleVerifyInteraction(payload.d);
          }
        }
      })().catch((error) => logger.error({ err: error }, "Discord interaction handling failed"));
    });
    socket.addEventListener("error", (event) => {
      logger.warn({ error: event }, "Discord bot gateway error");
    });
    socket.addEventListener("close", (event) => {
      if (heartbeat) clearInterval(heartbeat);
      const code = typeof event === "object" && event !== null && "code" in event ? event.code : undefined;
      logger.warn({ code }, "Discord bot gateway disconnected");
      if (!intentionalClose && code !== 4004) {
        setTimeout(connect, 5_000);
      }
      intentionalClose = true;
    });
  };

  setInterval(() => void processReinviteQueue().catch((error) => logger.warn({ err: error }, "Reinvite queue processing failed")), 60_000);
  connect();
}