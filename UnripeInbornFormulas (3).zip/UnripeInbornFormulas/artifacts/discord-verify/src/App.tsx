import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Route, Switch, useLocation, useParams, Router as WouterRouter } from 'wouter';
import {
  Activity as ActivityIcon,
  AlertTriangle,
  ArrowUpRight,
  BadgeCheck,
  Bot,
  Check,
  ChevronDown,
  CircleCheck,
  Clock3,
  Database,
  Hash,
  LayoutDashboard,
  Menu,
  MessageSquare,
  PanelLeft,
  RefreshCw,
  Save,
  Server,
  Settings as SettingsIcon,
  ShieldCheck,
  TrendingUp,
  Users,
  X,
} from 'lucide-react';
import {
  getGetDiscordGuildsQueryKey,
  getGetDiscordMeQueryKey,
  getGetGuildActivityQueryKey,
  getGetGuildConfigQueryKey,
  getGetGuildStatsQueryKey,
  getGetGuildMembersQueryKey,
  getGetVerifiedMembersQueryKey,
  useGetDiscordGuilds,
  useGetDiscordMe,
  useGetGuildActivity,
  useGetGuildConfig,
  useGetGuildMembers,
  useGetGuildStats,
  useGetVerifiedMembers,
  useReinviteGuildMembers,
  useSyncGuild,
  useUpdateGuildConfig,
} from '@workspace/api-client-react';
import type { ActivityItem, DiscordGuild, GlobalVerifiedMember, GuildStats, VerifyConfigInput } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

const formatNumber = (value: number | null | undefined) => new Intl.NumberFormat('en-US').format(value ?? 0);
const formatTime = (value?: string | null) =>
  value
    ? new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }).format(new Date(value))
    : 'Not synced yet';
const initials = (value?: string | null) => (value || 'DC').split(/\s+/).map((part) => part[0]).join('').slice(0, 2).toUpperCase();
const hasAdministratorPermission = (guild: DiscordGuild) => {
  try {
    return (BigInt(guild.permissions) & 8n) === 8n;
  } catch {
    return false;
  }
};

function DiscordMark({ small = false }: { small?: boolean }) {
  return (
    <span className={`flex shrink-0 items-center justify-center rounded-[10px] bg-[#5865f2] text-white shadow-[0_5px_16px_rgba(88,101,242,.25)] ${small ? 'h-8 w-8' : 'h-10 w-10'}`} aria-hidden="true">
      <span className={`font-display font-bold tracking-[-.08em] ${small ? 'text-[15px]' : 'text-lg'}`}>D</span>
    </span>
  );
}

function StatusDot({ active = true }: { active?: boolean }) {
  return <span className={`inline-block h-2 w-2 rounded-full ${active ? 'bg-[#53d39a] pulse-dot' : 'bg-[#d36b62]'}`} aria-hidden="true" />;
}

function MetricCard({ label, value, detail, icon, accent, delay = '' }: { label: string; value: string; detail: string; icon: ReactNode; accent: string; delay?: string }) {
  return (
    <article className={`panel-shadow rise-in ${delay} rounded-2xl border hairline bg-card p-5`} data-testid={`card-metric-${label.toLowerCase().replaceAll(' ', '-')}`}>
      <div className="flex items-start justify-between">
        <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${accent}`}>{icon}</div>
        <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
      </div>
      <p className="mt-5 text-[11px] font-bold uppercase tracking-[.14em] text-muted-foreground" data-testid={`text-label-${label.toLowerCase().replaceAll(' ', '-')}`}>{label}</p>
      <p className="mt-1 font-display text-3xl font-bold tracking-[-.05em] text-foreground" data-testid={`text-value-${label.toLowerCase().replaceAll(' ', '-')}`}>{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{detail}</p>
    </article>
  );
}

function LoadingBlock({ lines = 4 }: { lines?: number }) {
  return (
    <div className="space-y-3 animate-pulse" data-testid="loading-block">
      {Array.from({ length: lines }).map((_, index) => <div key={index} className={`h-4 rounded-md bg-secondary ${index === 0 ? 'w-2/3' : index === lines - 1 ? 'w-1/3' : 'w-full'}`} />)}
    </div>
  );
}

function QueryError({ message = 'We could not load this view.' }: { message?: string }) {
  return (
    <div className="rounded-2xl border border-[#e6b4ad] bg-[#fff6f3] p-6" data-testid="status-query-error">
      <div className="flex gap-3">
        <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-[#b44f45]" />
        <div>
          <p className="font-semibold text-[#713c38]">A Discord connection hiccup</p>
          <p className="mt-1 text-sm text-[#8e5a54]">{message}</p>
        </div>
      </div>
    </div>
  );
}

type AuthState = {
  passwordConfigured: boolean;
  passwordPassed: boolean;
  discordConfigured: boolean;
  discordAuthenticated: boolean;
  user: { username: string; globalName: string | null; avatar: string | null } | null;
};

function AuthGate({ children }: { children: ReactNode }) {
  const [auth, setAuth] = useState<AuthState | null>(null);
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const load = async () => {
    const response = await fetch('/api/auth/status', { credentials: 'include' });
    if (!response.ok) throw new Error('Auth status unavailable');
    setAuth(await response.json() as AuthState);
  };
  useEffect(() => { void load().catch(() => setError('Der Zugangsdienst ist momentan nicht erreichbar.')); }, []);

  const submitPassword = async (event: FormEvent) => {
    event.preventDefault();
    setPending(true);
    setError(null);
    try {
      const response = await fetch('/api/auth/password', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      if (!response.ok) {
        const body = await response.json().catch(() => null) as { error?: string } | null;
        throw new Error(body?.error ?? 'Passwort abgelehnt.');
      }
      setAuth(await response.json() as AuthState);
      setPassword('');
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'Passwort abgelehnt.');
    } finally {
      setPending(false);
    }
  };

  if (!auth) {
    return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f4f7f8] p-5"><div className="h-10 w-10 animate-spin rounded-full border-4 border-[#d8e6ea] border-t-[#5865f2]" /></div>;
  }
  if (!auth.passwordConfigured) {
    return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f4f7f8] p-5"><div className="max-w-md rounded-3xl border hairline bg-card p-8 text-center shadow-xl"><DiscordMark /><h1 className="mt-5 font-display text-2xl font-bold">Dashboard-Zugang einrichten</h1><p className="mt-3 text-sm leading-6 text-muted-foreground">Der geheime Dashboard-Schlüssel ist noch nicht als Secret hinterlegt. Hinterlege DASHBOARD_PASSWORD, damit nur autorisierte Personen Zugriff erhalten.</p></div></div>;
  }
  if (!auth.passwordPassed) {
    return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f4f7f8] p-5"><form onSubmit={submitPassword} className="w-full max-w-md rounded-3xl border hairline bg-card p-8 shadow-xl"><DiscordMark /><p className="mt-6 font-mono text-[10px] font-bold uppercase tracking-[.16em] text-primary">Private control center</p><h1 className="mt-2 font-display text-3xl font-bold tracking-[-.05em]">Dashboard öffnen</h1><p className="mt-3 text-sm leading-6 text-muted-foreground">Gib das gemeinsame Zugangspasswort ein. Danach bestätigst du noch dein Discord-Konto.</p><label className="mt-6 block"><span className="mb-2 block text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">Passwort</span><input autoFocus autoComplete="current-password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} className="button-focus w-full rounded-xl border hairline bg-background px-4 py-3 text-sm" data-testid="input-dashboard-password" /></label>{error && <p className="mt-3 rounded-xl bg-[#fff0ed] px-3 py-2 text-sm font-semibold text-[#9b493f]">{error}</p>}<button disabled={pending || !password} className="mt-5 w-full rounded-xl bg-[#5865f2] px-4 py-3 text-sm font-bold text-white disabled:opacity-50" data-testid="button-submit-password">{pending ? 'Prüfe Zugang…' : 'Weiter'}</button></form></div>;
  }
  if (!auth.discordConfigured || !auth.discordAuthenticated) {
    return <div className="flex min-h-[100dvh] items-center justify-center bg-[#f4f7f8] p-5"><div className="w-full max-w-md rounded-3xl border hairline bg-card p-8 shadow-xl"><DiscordMark /><p className="mt-6 font-mono text-[10px] font-bold uppercase tracking-[.16em] text-primary">Second factor</p><h1 className="mt-2 font-display text-3xl font-bold tracking-[-.05em]">Discord bestätigen</h1><p className="mt-3 text-sm leading-6 text-muted-foreground">{auth.discordConfigured ? 'Melde dich mit dem Discord-Konto an, dessen Server du verwalten möchtest.' : 'DISCORD_CLIENT_ID und DISCORD_CLIENT_SECRET müssen noch als Secrets hinterlegt und im Discord Developer Portal als OAuth-Redirect registriert werden.'}</p>{auth.discordConfigured && <div className="mt-4 rounded-xl bg-secondary/70 p-3"><p className="text-[10px] font-bold uppercase tracking-[.1em] text-muted-foreground">OAuth Redirect URL</p><code className="mt-1 block break-all text-[11px] leading-5 text-foreground">{window.location.origin}/api/auth/discord/callback</code></div>}{error && <p className="mt-3 rounded-xl bg-[#fff0ed] px-3 py-2 text-sm font-semibold text-[#9b493f]">{error}</p>}{auth.discordConfigured && <a href={`/api/auth/discord/start?returnTo=${encodeURIComponent(window.location.pathname)}`} className="mt-6 inline-flex w-full items-center justify-center rounded-xl bg-[#5865f2] px-4 py-3 text-sm font-bold text-white">Mit Discord anmelden</a>}</div></div>;
  }
  return <>{children}</>;
}

function EmptyState({ title, copy, icon }: { title: string; copy: string; icon: ReactNode }) {
  return (
    <div className="flex min-h-[220px] flex-col items-center justify-center rounded-2xl border border-dashed hairline bg-card/60 px-6 text-center" data-testid="status-empty">
      <div className="mb-3 flex h-11 w-11 items-center justify-center rounded-xl bg-secondary text-primary">{icon}</div>
      <p className="font-display text-lg font-bold text-foreground">{title}</p>
      <p className="mt-1 max-w-sm text-sm leading-6 text-muted-foreground">{copy}</p>
    </div>
  );
}

function ActivityRow({ item }: { item: ActivityItem }) {
  const icon = item.type === 'verified' ? <BadgeCheck className="h-4 w-4" /> : item.type === 'warning' ? <AlertTriangle className="h-4 w-4" /> : item.type === 'synced' ? <RefreshCw className="h-4 w-4" /> : <SettingsIcon className="h-4 w-4" />;
  const color = item.type === 'warning' ? 'bg-[#fff0dc] text-[#a66419]' : item.type === 'verified' ? 'bg-[#e0f5ea] text-[#267a52]' : 'bg-[#e3f2f5] text-[#277082]';
  return (
    <div className="group flex gap-4 border-b hairline py-4 last:border-b-0" data-testid={`row-activity-${item.id}`}>
      <div className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${color}`}>{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
          <p className="font-semibold text-foreground" data-testid={`text-activity-title-${item.id}`}>{item.title}</p>
          <time className="font-mono text-[10px] uppercase tracking-[.08em] text-muted-foreground">{formatTime(item.createdAt)}</time>
        </div>
        <p className="mt-1 text-sm leading-6 text-muted-foreground">{item.description}</p>
        {item.actor && <p className="mt-2 text-[11px] font-semibold uppercase tracking-[.1em] text-primary">Actor · {item.actor}</p>}
      </div>
    </div>
  );
}

function Sidebar({ guilds, selectedGuild, setSelectedGuild, mobileOpen, setMobileOpen }: {
  guilds: DiscordGuild[];
  selectedGuild: DiscordGuild | null;
  setSelectedGuild: (guild: DiscordGuild) => void;
  mobileOpen: boolean;
  setMobileOpen: (open: boolean) => void;
}) {
  const [location] = useLocation();
  const [guildOpen, setGuildOpen] = useState(false);
  const navItems = [
    { href: '/', label: 'Overview', icon: LayoutDashboard },
    { href: '/members', label: 'Verified members', icon: Users },
    { href: '/activity', label: 'Activity log', icon: ActivityIcon },
    { href: '/settings', label: 'Verification settings', icon: SettingsIcon },
  ];
  return (
    <>
      {mobileOpen && <button className="fixed inset-0 z-30 bg-[#101731]/55 md:hidden" onClick={() => setMobileOpen(false)} data-testid="button-close-mobile-sidebar" aria-label="Close navigation" />}
      <aside className={`sidebar-grid fixed inset-y-0 left-0 z-40 flex w-[272px] flex-col bg-sidebar text-sidebar-foreground transition-transform duration-300 md:translate-x-0 ${mobileOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex h-[76px] items-center justify-between border-b border-sidebar-border px-6">
          <Link href="/" className="flex items-center gap-3" onClick={() => setMobileOpen(false)} data-testid="link-brand-home">
            <DiscordMark />
            <div>
              <p className="font-display text-[15px] font-bold tracking-[-.03em] text-white">Verifyline</p>
              <p className="font-mono text-[9px] uppercase tracking-[.18em] text-sidebar-foreground/55">control center</p>
            </div>
          </Link>
          <button className="rounded-lg p-1.5 text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-white md:hidden" onClick={() => setMobileOpen(false)} data-testid="button-close-sidebar"><X className="h-4 w-4" /></button>
        </div>
        <div className="px-4 pt-6">
          <p className="px-3 text-[10px] font-bold uppercase tracking-[.16em] text-sidebar-foreground/42">Workspace</p>
          <div className="relative mt-2">
            <button className="flex w-full items-center gap-3 rounded-xl border border-sidebar-border bg-sidebar-accent/75 p-3 text-left transition-colors hover:bg-sidebar-accent" onClick={() => setGuildOpen(!guildOpen)} data-testid="button-open-guild-selector">
              {selectedGuild?.icon ? <img src={selectedGuild.icon} alt="" className="h-8 w-8 rounded-lg object-cover" /> : <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#5865f2] text-xs font-bold text-white">{initials(selectedGuild?.name)}</span>}
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold text-white" data-testid="text-selected-guild">{selectedGuild?.name ?? 'Select a server'}</span>
                <span className="block font-mono text-[9px] uppercase tracking-[.08em] text-sidebar-foreground/55">{selectedGuild ? `${formatNumber(selectedGuild.memberCount)} members` : 'No server selected'}</span>
              </span>
              <ChevronDown className={`h-4 w-4 shrink-0 text-sidebar-foreground/60 transition-transform ${guildOpen ? 'rotate-180' : ''}`} />
            </button>
            {guildOpen && (
               <div className="absolute left-0 right-0 top-[calc(100%+8px)] z-50 max-h-[min(60vh,440px)] overflow-y-auto rounded-xl border border-sidebar-border bg-[#202742] p-1.5 shadow-2xl" data-testid="menu-guild-selector">
                {guilds.map((guild) => (
                  <button key={guild.id} className="flex w-full items-center gap-3 rounded-lg p-2.5 text-left hover:bg-sidebar-accent" onClick={() => { setSelectedGuild(guild); setGuildOpen(false); }} data-testid={`button-select-guild-${guild.id}`}>
                    {guild.icon ? <img src={guild.icon} alt="" className="h-7 w-7 rounded-lg object-cover" /> : <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#5865f2] text-[10px] font-bold text-white">{initials(guild.name)}</span>}
                    <span className="min-w-0 flex-1 truncate text-xs font-semibold text-white">{guild.name}</span>
                    {guild.id === selectedGuild?.id && <Check className="h-3.5 w-3.5 text-sidebar-primary" />}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
        <nav className="mt-8 px-4" aria-label="Main navigation">
          <p className="px-3 text-[10px] font-bold uppercase tracking-[.16em] text-sidebar-foreground/42">Operate</p>
          <div className="mt-2 space-y-1">
            {navItems.map(({ href, label, icon: Icon }) => {
              const active = location === href;
              return <Link key={href} href={href} onClick={() => setMobileOpen(false)} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold transition-all ${active ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-[0_7px_20px_rgba(86,207,225,.16)]' : 'text-sidebar-foreground/68 hover:bg-sidebar-accent hover:text-white'}`} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`}><Icon className="h-[17px] w-[17px]" /><span>{label}</span>{active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-sidebar-primary-foreground" />}</Link>;
            })}
          </div>
        </nav>
        <div className="mt-auto px-5 pb-5">
          <div className="rounded-2xl border border-sidebar-border bg-[#18203a]/70 p-4">
            <div className="flex items-center gap-2"><StatusDot active={!!selectedGuild?.botPresent} /><span className="font-mono text-[10px] uppercase tracking-[.12em] text-sidebar-foreground/62">Bot status</span></div>
            <p className="mt-2 font-display text-sm font-bold text-white">{selectedGuild?.botPresent ? hasAdministratorPermission(selectedGuild) ? 'Connected · Administrator' : 'Connected · Admin needed' : 'Bot not detected'}</p>
            <p className="mt-1 text-xs leading-5 text-sidebar-foreground/52">{selectedGuild?.botPresent ? hasAdministratorPermission(selectedGuild) ? 'Ready to manage verification.' : 'Use Add bot · Admin to approve the requested permission.' : 'Invite Verifyline to activate this server.'}</p>
          </div>
          <div className="mt-4 flex items-center gap-2 px-2 text-sidebar-foreground/42"><ShieldCheck className="h-3.5 w-3.5" /><span className="font-mono text-[9px] uppercase tracking-[.11em]">Trust by design</span></div>
        </div>
      </aside>
    </>
  );
}

function Header({ title, eyebrow, onMenu, userName, avatar }: { title: string; eyebrow: string; onMenu: () => void; userName?: string; avatar?: string | null }) {
  return (
    <header className="flex min-h-[76px] items-center justify-between border-b hairline px-5 py-4 md:px-10">
      <div className="flex items-center gap-3">
        <button className="rounded-xl border hairline bg-card p-2.5 text-muted-foreground md:hidden" onClick={onMenu} data-testid="button-open-mobile-sidebar"><Menu className="h-5 w-5" /></button>
        <div><p className="font-mono text-[10px] font-medium uppercase tracking-[.16em] text-primary">{eyebrow}</p><h1 className="mt-0.5 font-display text-xl font-bold tracking-[-.04em] text-foreground md:text-2xl" data-testid="text-page-title">{title}</h1></div>
      </div>
      <div className="flex items-center gap-3">
        <a href="/api/auth/discord/install" className="inline-flex items-center gap-2 rounded-xl bg-primary px-3 py-2.5 text-xs font-bold text-primary-foreground transition-transform hover:-translate-y-0.5 sm:px-4" aria-label="Add the bot to a server; requests Administrator permissions" title="Requests Administrator permission. A server owner or member with Manage Server must approve." data-testid="link-install-bot"><Bot className="h-4 w-4" /><span>Add bot · Admin</span></a>
        <div className="hidden items-center gap-2 rounded-full border hairline bg-card px-3 py-2 text-xs font-semibold text-muted-foreground sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-[#53d39a]" /> All systems operational</div>
        <div className="flex h-9 w-9 items-center justify-center overflow-hidden rounded-full bg-[#d9e7eb] text-xs font-bold text-primary" data-testid="avatar-user">{avatar ? <img src={avatar} alt="" className="h-full w-full object-cover" /> : initials(userName)}</div>
      </div>
    </header>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [selectedGuild, setSelectedGuildState] = useState<DiscordGuild | null>(null);
  const me = useGetDiscordMe({ query: { queryKey: getGetDiscordMeQueryKey() } });
  const guildQuery = useGetDiscordGuilds({ query: { queryKey: getGetDiscordGuildsQueryKey() } });
  const guilds = guildQuery.data ?? [];
  useEffect(() => {
    if (!guilds.length) return;
    const saved = localStorage.getItem('verifyline:selected-guild');
    const next = guilds.find((guild) => guild.id === saved) ?? guilds[0];
    setSelectedGuildState(next);
  }, [guilds]);
  const setSelectedGuild = (guild: DiscordGuild) => {
    localStorage.setItem('verifyline:selected-guild', guild.id);
    setSelectedGuildState(guild);
  };
  const [location] = useLocation();
  const header = location === '/settings' ? ['Verification settings', 'Configure your flow'] : location === '/activity' ? ['Activity log', 'A clear audit trail'] : location === '/members' ? ['Verified members', 'Cross-server member intelligence'] : ['Overview', 'Server command center'];
  return (
    <div className="min-h-[100dvh] app-shell">
      <Sidebar guilds={guilds} selectedGuild={selectedGuild} setSelectedGuild={setSelectedGuild} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />
      <main className="min-h-[100dvh] md:pl-[272px]">
        <Header title={header[0]} eyebrow={header[1]} onMenu={() => setMobileOpen(true)} userName={me.data?.globalName ?? me.data?.username} avatar={me.data?.avatar} />
        <div className="mx-auto max-w-[1440px] px-5 py-7 md:px-10 md:py-9">
          {guildQuery.isLoading ? <div className="rounded-2xl border hairline bg-card p-8"><LoadingBlock lines={6} /></div> : guildQuery.isError ? <QueryError message="Die Bot-Server konnten nicht geladen werden. Prüfe die API-Verbindung." /> : !guilds.length ? <EmptyState title="Keine verbundenen Bot-Server" copy="Sobald Verifyline einem Discord-Server hinzugefügt wurde, erscheint er hier." icon={<Server className="h-5 w-5" />} /> : children}
        </div>
      </main>
    </div>
  );
}

function ServerHero({ guild, stats, onSync, syncing }: { guild: DiscordGuild; stats?: GuildStats; onSync: () => void; syncing: boolean }) {
  return (
    <section className="rise-in relative overflow-hidden rounded-3xl bg-[#202942] p-6 text-white shadow-[0_20px_50px_rgba(31,43,70,.18)] md:p-8">
      <div className="absolute -right-24 -top-28 h-72 w-72 rounded-full border-[34px] border-[#56cfe1]/10" />
      <div className="absolute -bottom-32 right-20 h-64 w-64 rounded-full border border-[#f0b446]/15" />
      <div className="relative flex flex-col justify-between gap-8 md:flex-row md:items-end">
        <div>
          <div className="flex items-center gap-3">
            {guild.icon ? <img src={guild.icon} alt="" className="h-14 w-14 rounded-2xl object-cover ring-4 ring-white/10" /> : <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#5865f2] font-display text-xl font-bold ring-4 ring-white/10">{initials(guild.name)}</span>}
            <div><p className="font-mono text-[10px] uppercase tracking-[.15em] text-[#a8b8cf]">Selected server</p><h2 className="mt-1 font-display text-2xl font-bold tracking-[-.05em] md:text-3xl" data-testid="text-server-name">{guild.name}</h2></div>
          </div>
          <div className="mt-7 flex flex-wrap items-center gap-2 text-xs text-[#b7c5d7]">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/[.08] px-3 py-1.5"><Users className="h-3.5 w-3.5" /> {formatNumber(guild.memberCount)} members</span>
            <span className="inline-flex items-center gap-2 rounded-full bg-white/[.08] px-3 py-1.5"><StatusDot active={guild.botPresent} /> {guild.botPresent ? 'Bot is present' : 'Bot needs attention'}</span>
          </div>
        </div>
        <div className="flex flex-col items-start gap-3 md:items-end">
          <div className="flex items-center gap-2 text-xs text-[#b7c5d7]"><span className={`h-2 w-2 rounded-full ${stats?.botOnline ? 'bg-[#53d39a] pulse-dot' : 'bg-[#d36b62]'}`} /> {stats?.botOnline ? 'Verification service online' : 'Verification service offline'}</div>
          <button className="button-focus inline-flex items-center gap-2 rounded-xl bg-[#56cfe1] px-4 py-2.5 text-xs font-bold text-[#132039] transition-transform hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-70" onClick={onSync} disabled={syncing} data-testid="button-sync-server">{syncing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />} {syncing ? 'Syncing server' : 'Sync with Discord'}</button>
          <p className="font-mono text-[9px] uppercase tracking-[.1em] text-[#8191aa]">Last sync · {formatTime(stats?.lastSyncAt)}</p>
        </div>
      </div>
    </section>
  );
}

function OverviewPage({ guild }: { guild: DiscordGuild }) {
  const client = useQueryClient();
  const statsQuery = useGetGuildStats(guild.id, { query: { enabled: !!guild.id, queryKey: getGetGuildStatsQueryKey(guild.id) } });
  const configQuery = useGetGuildConfig(guild.id, { query: { enabled: !!guild.id, queryKey: getGetGuildConfigQueryKey(guild.id) } });
  const activityQuery = useGetGuildActivity(guild.id, { query: { enabled: !!guild.id, queryKey: getGetGuildActivityQueryKey(guild.id) } });
  const sync = useSyncGuild();
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const stats = statsQuery.data;
  const config = configQuery.data;
  const recent = (activityQuery.data ?? []).slice(0, 4);
  const syncServer = () => {
    setSyncMessage(null);
    sync.mutate({ guildId: guild.id }, { onSuccess: (result) => { setSyncMessage(result.message); client.invalidateQueries({ queryKey: getGetGuildStatsQueryKey(guild.id) }); client.invalidateQueries({ queryKey: getGetGuildActivityQueryKey(guild.id) }); client.invalidateQueries({ queryKey: getGetDiscordGuildsQueryKey() }); }, onError: () => setSyncMessage('Sync could not be completed. Try again in a moment.') });
  };
  return (
    <div className="space-y-7">
      <ServerHero guild={guild} stats={stats} onSync={syncServer} syncing={sync.isPending} />
      {syncMessage && <div className="rise-in flex items-center gap-2 rounded-xl border border-[#a8dbc4] bg-[#effaf4] px-4 py-3 text-sm font-semibold text-[#28704e]" data-testid="status-sync-result"><Check className="h-4 w-4" />{syncMessage}</div>}
      {(statsQuery.isError || configQuery.isError) && <QueryError message="Some server signals are unavailable right now. Activity can still be reviewed below." />}
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="Verified members" value={formatNumber(stats?.verifiedMembers)} detail={`${formatNumber(stats?.verifiedToday)} verified today`} icon={<BadgeCheck className="h-5 w-5 text-[#267a52]" />} accent="bg-[#e0f5ea]" delay="rise-in-delay-1" />
        <MetricCard label="Verification rate" value={`${(stats?.verificationRate ?? 0).toFixed(1)}%`} detail="of total members" icon={<TrendingUp className="h-5 w-5 text-[#277082]" />} accent="bg-[#e3f2f5]" delay="rise-in-delay-2" />
        <MetricCard label="Pending queue" value={formatNumber(stats?.pendingMembers)} detail="members awaiting review" icon={<Clock3 className="h-5 w-5 text-[#a66419]" />} accent="bg-[#fff0dc]" delay="rise-in-delay-3" />
        <MetricCard label="Total members" value={formatNumber(stats?.totalMembers ?? guild.memberCount)} detail="in this Discord server" icon={<Users className="h-5 w-5 text-[#5865f2]" />} accent="bg-[#e9e9fb]" delay="rise-in-delay-3" />
      </div>
      <div className="grid gap-6 xl:grid-cols-[1.35fr_.65fr]">
        <section className="panel-shadow rise-in rounded-2xl border hairline bg-card p-5 md:p-6">
          <div className="flex items-start justify-between gap-4"><div><p className="font-mono text-[10px] uppercase tracking-[.14em] text-primary">Recent movement</p><h3 className="mt-1 font-display text-xl font-bold tracking-[-.04em]">Activity worth knowing about</h3></div><Link href="/activity" className="inline-flex items-center gap-1 text-xs font-bold text-primary hover:underline" data-testid="link-view-all-activity">View all <ArrowUpRight className="h-3.5 w-3.5" /></Link></div>
          <div className="mt-4">{activityQuery.isLoading ? <LoadingBlock lines={4} /> : activityQuery.isError ? <QueryError message="Activity is temporarily unavailable." /> : recent.length ? recent.map((item) => <ActivityRow key={item.id} item={item} />) : <EmptyState title="A quiet server" copy="Verification events will appear here as your community moves through the flow." icon={<ActivityIcon className="h-5 w-5" />} />}</div>
        </section>
        <section className="panel-shadow rise-in rounded-2xl border hairline bg-card p-5 md:p-6">
          <p className="font-mono text-[10px] uppercase tracking-[.14em] text-primary">Flow posture</p><h3 className="mt-1 font-display text-xl font-bold tracking-[-.04em]">Verification is {config?.enabled ? 'live' : 'paused'}</h3>
          <div className="mt-5 flex items-center gap-4 rounded-xl bg-secondary/70 p-4"><div className={`flex h-11 w-11 items-center justify-center rounded-xl ${config?.enabled ? 'bg-[#dff4e9] text-[#267a52]' : 'bg-[#fff0dc] text-[#a66419]'}`}>{config?.enabled ? <ShieldCheck className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}</div><div><p className="text-sm font-bold">{config?.enabled ? 'Guardrails are active' : 'Action needed'}</p><p className="mt-0.5 text-xs leading-5 text-muted-foreground">{config?.enabled ? 'New members can verify through your configured channel.' : 'Turn verification on when your channel and role are ready.'}</p></div></div>
          <dl className="mt-5 space-y-3 text-sm"><div className="flex items-center justify-between border-b hairline pb-3"><dt className="flex items-center gap-2 text-muted-foreground"><Hash className="h-3.5 w-3.5" /> Channel</dt><dd className="max-w-[150px] truncate font-mono text-xs font-medium">{config?.verifyChannelId ? `#${config.verifyChannelId}` : 'Not configured'}</dd></div><div className="flex items-center justify-between border-b hairline pb-3"><dt className="flex items-center gap-2 text-muted-foreground"><BadgeCheck className="h-3.5 w-3.5" /> Auto-role</dt><dd className="font-semibold">{config?.autoRoleEnabled ? 'Enabled' : 'Off'}</dd></div></dl>
          <Link href="/settings" className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl border hairline px-4 py-3 text-xs font-bold text-foreground transition-colors hover:bg-secondary" data-testid="link-edit-settings">Review verification settings <ArrowUpRight className="h-3.5 w-3.5" /></Link>
        </section>
      </div>
    </div>
  );
}

function ActivityPage({ guild }: { guild: DiscordGuild }) {
  const activityQuery = useGetGuildActivity(guild.id, { query: { enabled: !!guild.id, queryKey: getGetGuildActivityQueryKey(guild.id) } });
  const items = activityQuery.data ?? [];
  return (
    <div className="space-y-7">
      <div className="rise-in flex flex-col justify-between gap-4 md:flex-row md:items-end"><div><p className="max-w-xl text-sm leading-6 text-muted-foreground">A transparent record of verification events, configuration changes, and Discord syncs for <span className="font-semibold text-foreground">{guild.name}</span>.</p></div><div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[.12em] text-muted-foreground"><Database className="h-3.5 w-3.5" /> {items.length} recorded events</div></div>
      <section className="panel-shadow rise-in rounded-2xl border hairline bg-card p-5 md:p-7">
        <div className="flex items-center justify-between border-b hairline pb-4"><div><p className="font-mono text-[10px] uppercase tracking-[.14em] text-primary">Event stream</p><h2 className="mt-1 font-display text-2xl font-bold tracking-[-.05em]">What changed, and when</h2></div><div className="hidden rounded-full bg-secondary px-3 py-1.5 text-[10px] font-bold uppercase tracking-[.1em] text-muted-foreground sm:block">Newest first</div></div>
        <div className="mt-2">{activityQuery.isLoading ? <LoadingBlock lines={7} /> : activityQuery.isError ? <QueryError message="The activity stream could not be loaded." /> : items.length ? items.map((item) => <ActivityRow key={item.id} item={item} />) : <EmptyState title="No activity yet" copy="The first verification or configuration event will create a useful trail here." icon={<Database className="h-5 w-5" />} />}</div>
      </section>
    </div>
  );
}

function MembersPage({ guilds }: { guilds: DiscordGuild[] }) {
  const client = useQueryClient();
  const botGuilds = guilds.filter((guild) => guild.botPresent);
  const [selectedSourceIds, setSelectedSourceIds] = useState<string[]>(() => botGuilds.map((guild) => guild.id));
  useEffect(() => {
    const availableIds = botGuilds.map((guild) => guild.id);
    setSelectedSourceIds((current) => [
      ...current.filter((id) => availableIds.includes(id)),
      ...availableIds.filter((id) => !current.includes(id)),
    ]);
  }, [guilds]);
  const selectedSources = botGuilds.filter((guild) => selectedSourceIds.includes(guild.id));
  const guildIds = selectedSources.length === botGuilds.length ? undefined : selectedSources.map((guild) => guild.id).join(',');
  const memberParams = { limit: 100, ...(guildIds === undefined ? {} : { guildIds }) };
  const membersQuery = useGetVerifiedMembers(memberParams, {
    query: {
      queryKey: getGetVerifiedMembersQueryKey(memberParams),
      enabled: selectedSources.length > 0,
    },
  });
  const reinvite = useReinviteGuildMembers();
  const [targetGuildId, setTargetGuildId] = useState(guilds.find((guild) => guild.botPresent)?.id ?? guilds[0]?.id ?? '');
  const [amount, setAmount] = useState(10);
  const [result, setResult] = useState<string | null>(null);
  const members = membersQuery.data ?? [];
  const targetGuild = guilds.find((guild) => guild.id === targetGuildId);
  const toggleSourceGuild = (guildId: string, checked: boolean) => {
    setSelectedSourceIds((current) => checked ? [...current, guildId] : current.filter((id) => id !== guildId));
  };
  const sendInvites = () => {
    if (!targetGuildId) return;
    setResult(null);
    reinvite.mutate({ guildId: targetGuildId, data: { limit: amount } }, {
      onSuccess: (response) => {
        setResult(response.message);
        client.invalidateQueries({ queryKey: getGetVerifiedMembersQueryKey() });
      },
      onError: () => setResult('Die Einladungen konnten nicht versendet werden. Prüfe Bot-Rechte und den Verify-Kanal.'),
    });
  };
  return (
    <div className="space-y-7">
      <div className="rise-in flex flex-col justify-between gap-4 md:flex-row md:items-end">
       <div><p className="max-w-2xl text-sm leading-6 text-muted-foreground">Alle Mitglieder, die über Verifyline verifiziert wurden. Wähle die verbundenen Bot-Server aus, die in die Gesamtliste einfließen sollen.</p></div>
        <div className="rounded-full bg-secondary px-3 py-1.5 font-mono text-[10px] font-bold uppercase tracking-[.1em] text-muted-foreground">{members.length} profile loaded</div>
      </div>
      <section className="panel-shadow rise-in rounded-2xl border hairline bg-card p-5 md:p-6" data-testid="panel-member-source-servers">
        <div className="flex flex-col justify-between gap-3 border-b hairline pb-4 sm:flex-row sm:items-center">
          <div><p className="font-mono text-[10px] uppercase tracking-[.14em] text-primary">Source servers</p><h2 className="mt-1 font-display text-xl font-bold tracking-[-.04em]">Bot-Server für die Gesamtliste</h2></div>
          <label className="inline-flex items-center gap-2 text-sm font-semibold text-foreground">
            <input type="checkbox" className="h-4 w-4 accent-primary" checked={botGuilds.length > 0 && selectedSources.length === botGuilds.length} onChange={(event) => setSelectedSourceIds(event.currentTarget.checked ? botGuilds.map((guild) => guild.id) : [])} data-testid="checkbox-source-all" />
            Alle verbundenen Server
          </label>
        </div>
        <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {botGuilds.map((guild) => (
            <label key={guild.id} className="flex cursor-pointer items-center gap-3 rounded-xl border hairline bg-background px-3 py-3 text-sm font-semibold transition-colors hover:bg-secondary/60">
              <input type="checkbox" className="h-4 w-4 shrink-0 accent-primary" checked={selectedSourceIds.includes(guild.id)} onChange={(event) => toggleSourceGuild(guild.id, event.currentTarget.checked)} data-testid={`checkbox-source-${guild.id}`} />
              {guild.icon ? <img src={guild.icon} alt="" className="h-7 w-7 rounded-lg object-cover" /> : <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#5865f2] text-[10px] font-bold text-white">{initials(guild.name)}</span>}
              <span className="min-w-0 flex-1 truncate">{guild.name}</span>
              <StatusDot active />
            </label>
          ))}
        </div>
        <p className="mt-3 text-xs leading-5 text-muted-foreground">Es erscheinen nur Server, auf denen Verifyline installiert ist. „Alle verbundenen Server“ bildet die serverübergreifende Mitgliederliste.</p>
      </section>
      <section className="panel-shadow rise-in rounded-2xl border hairline bg-card p-5 md:p-6">
        <div className="flex flex-col justify-between gap-4 border-b hairline pb-5 md:flex-row md:items-end">
          <div><p className="font-mono text-[10px] uppercase tracking-[.14em] text-primary">Member routing</p><h2 className="mt-1 font-display text-2xl font-bold tracking-[-.05em]">Verifizierte Mitglieder einladen</h2><p className="mt-1 max-w-2xl text-sm leading-6 text-muted-foreground">Wähle einen Server und eine Anzahl. Der Bot sendet individuelle Einladungen per Discord-DM; er kann niemanden ohne Zustimmung automatisch einem Server hinzufügen.</p></div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <select value={targetGuildId} onChange={(event) => setTargetGuildId(event.target.value)} className="button-focus rounded-xl border hairline bg-background px-3 py-2.5 text-sm font-semibold" data-testid="select-reinvite-target">
              {guilds.filter((guild) => guild.botPresent).map((guild) => <option key={guild.id} value={guild.id}>{guild.name}</option>)}
            </select>
            <input type="number" min={1} max={100} value={amount} onChange={(event) => setAmount(Math.min(100, Math.max(1, Number(event.target.value) || 1)))} className="button-focus w-24 rounded-xl border hairline bg-background px-3 py-2.5 text-sm font-semibold" aria-label="Number of members" data-testid="input-reinvite-amount" />
            <button onClick={sendInvites} disabled={reinvite.isPending || !targetGuildId || !targetGuild} className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-xs font-bold text-primary-foreground disabled:cursor-not-allowed disabled:opacity-50" data-testid="button-send-reinvites">{reinvite.isPending ? <RefreshCw className="h-4 w-4 animate-spin" /> : <ArrowUpRight className="h-4 w-4" />} Send invites</button>
          </div>
        </div>
        {result && <div className="mt-4 rounded-xl border border-[#a8dbc4] bg-[#effaf4] px-4 py-3 text-sm font-semibold text-[#28704e]" data-testid="status-reinvite-result">{result}</div>}
      </section>
      <section className="panel-shadow rise-in rounded-2xl border hairline bg-card p-5 md:p-7">
        <div className="flex items-center justify-between border-b hairline pb-4"><div><p className="font-mono text-[10px] uppercase tracking-[.14em] text-primary">Member directory</p><h2 className="mt-1 font-display text-2xl font-bold tracking-[-.05em]">Wer ist verifiziert?</h2></div><Users className="h-5 w-5 text-primary" /></div>
        {!selectedSources.length ? <div className="mt-6"><EmptyState title="Wähle mindestens einen Server" copy="Die Mitgliederliste wird aus den ausgewählten Servern zusammengestellt." icon={<Server className="h-5 w-5" />} /></div> : membersQuery.isLoading ? <div className="mt-6"><LoadingBlock lines={8} /></div> : membersQuery.isError ? <div className="mt-6"><QueryError message="Die serverübergreifende Mitgliederliste konnte nicht geladen werden." /></div> : members.length ? <div className="mt-2 divide-y hairline">{members.map((member: GlobalVerifiedMember) => <div key={member.userId} className="flex flex-col gap-4 py-5 md:flex-row md:items-center md:justify-between" data-testid={`row-verified-member-${member.userId}`}><div className="flex min-w-0 items-center gap-3"><div className="flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-secondary text-xs font-bold text-primary">{member.avatar ? <img src={member.avatar} alt="" className="h-full w-full object-cover" /> : initials(member.username)}</div><div className="min-w-0"><p className="truncate text-sm font-bold text-foreground">{member.username}</p><p className="mt-1 font-mono text-[10px] uppercase tracking-[.08em] text-muted-foreground">{member.verifiedAtEstimated ? member.verifiedAt ? `Verify role active · member since ${formatTime(member.verifiedAt)}` : 'Verify role active · date unknown' : `Verified ${formatTime(member.verifiedAt)}`}</p></div></div><div className="flex flex-wrap gap-2 md:max-w-[60%] md:justify-end">{member.guilds.length ? member.guilds.map((server) => <span key={server.id} className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10px] font-bold ${server.active ? 'bg-[#e0f5ea] text-[#267a52]' : 'bg-secondary text-muted-foreground'}`}><StatusDot active={server.active} />{server.name}</span>) : <span className="text-xs text-muted-foreground">No accessible server record</span>}</div></div>)}</div> : <EmptyState title="Noch keine verifizierten Mitglieder" copy="Sobald jemand den Verify-Button nutzt, erscheint das Profil hier mit seinen bekannten Servern." icon={<Users className="h-5 w-5" />} />}
      </section>
    </div>
  );
}

function SettingsPage({ guild }: { guild: DiscordGuild }) {
  const client = useQueryClient();
  const configQuery = useGetGuildConfig(guild.id, { query: { enabled: !!guild.id, queryKey: getGetGuildConfigQueryKey(guild.id) } });
  const update = useUpdateGuildConfig();
  const config = configQuery.data;
  const [form, setForm] = useState<VerifyConfigInput>({ enabled: false, verifyChannelId: '', verifyRoleId: '', verifyMessage: 'Welcome. Confirm you are a real member of the community to unlock the server.', buttonLabel: 'Verify me', autoRoleEnabled: true, autoReinviteEnabled: false });
  const [saved, setSaved] = useState(false);
  const initializedId = useRef<string | null>(null);
  useEffect(() => {
    if (config && initializedId.current !== guild.id) {
      initializedId.current = guild.id;
      setForm({ enabled: config.enabled, verifyChannelId: config.verifyChannelId ?? '', verifyRoleId: config.verifyRoleId ?? '', verifyMessage: config.verifyMessage, buttonLabel: config.buttonLabel, autoRoleEnabled: config.autoRoleEnabled, autoReinviteEnabled: config.autoReinviteEnabled });
    }
  }, [config, guild.id]);
  const updateField = <K extends keyof VerifyConfigInput>(key: K, value: VerifyConfigInput[K]) => setForm((current) => ({ ...current, [key]: value }));
  const save = (event: FormEvent) => {
    event.preventDefault();
    setSaved(false);
    update.mutate({ guildId: guild.id, data: { ...form, verifyChannelId: form.verifyChannelId?.trim() || null, verifyRoleId: form.verifyRoleId?.trim() || null } }, {
      onSuccess: (next) => {
        client.setQueryData(getGetGuildConfigQueryKey(guild.id), next);
        client.invalidateQueries({ queryKey: getGetGuildActivityQueryKey(guild.id) });
        setSaved(true);
        window.setTimeout(() => setSaved(false), 3500);
      },
    });
  };
  return (
    <div className="max-w-4xl space-y-7">
      <div className="rise-in"><p className="max-w-2xl text-sm leading-6 text-muted-foreground">Give members one clear path to trust. These settings control what they see and what Verifyline does after they click.</p></div>
      {configQuery.isLoading ? <div className="panel-shadow rounded-2xl border hairline bg-card p-7"><LoadingBlock lines={8} /></div> : configQuery.isError ? <QueryError message="Verification settings could not be loaded." /> : (
        <form onSubmit={save} className="space-y-6" data-testid="form-verification-settings">
          <section className="panel-shadow rise-in rounded-2xl border hairline bg-card p-5 md:p-7">
            <div className="flex flex-col justify-between gap-4 border-b hairline pb-5 sm:flex-row sm:items-center"><div><p className="font-mono text-[10px] uppercase tracking-[.14em] text-primary">01 / Availability</p><h2 className="mt-1 font-display text-xl font-bold tracking-[-.04em]">Verification gate</h2><p className="mt-1 text-sm text-muted-foreground">Decide whether new members can enter through the flow.</p></div><button type="button" onClick={() => updateField('enabled', !form.enabled)} className={`relative h-8 w-14 shrink-0 rounded-full transition-colors ${form.enabled ? 'bg-primary' : 'bg-secondary'}`} data-testid="button-toggle-verification"><span className={`absolute top-1 h-6 w-6 rounded-full bg-card shadow-sm transition-transform ${form.enabled ? 'translate-x-7' : 'translate-x-1'}`} /><span className="sr-only">Toggle verification</span></button></div>
            <div className="mt-5 flex items-center gap-3 rounded-xl border hairline bg-secondary/55 p-4"><div className={`h-2.5 w-2.5 rounded-full ${form.enabled ? 'bg-[#53d39a]' : 'bg-[#d3a347]'}`} /><p className="text-sm font-semibold">{form.enabled ? 'Verification is active for this server.' : 'Verification is paused.'}</p></div>
          </section>
          <section className="panel-shadow rise-in rounded-2xl border hairline bg-card p-5 md:p-7">
            <div className="border-b hairline pb-5"><p className="font-mono text-[10px] uppercase tracking-[.14em] text-primary">02 / Discord destinations</p><h2 className="mt-1 font-display text-xl font-bold tracking-[-.04em]">Where the flow lives</h2><p className="mt-1 text-sm text-muted-foreground">Use channel and role IDs copied from Discord developer mode.</p></div>
            <div className="mt-5 grid gap-5 md:grid-cols-2">
              <label className="block"><span className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-[.1em] text-muted-foreground"><Hash className="h-3.5 w-3.5 text-primary" /> Verification channel</span><input value={form.verifyChannelId ?? ''} onChange={(event) => updateField('verifyChannelId', event.target.value)} placeholder="e.g. 118402991…" className="button-focus w-full rounded-xl border hairline bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/65" data-testid="input-verify-channel" /></label>
              <label className="block"><span className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-[.1em] text-muted-foreground"><BadgeCheck className="h-3.5 w-3.5 text-primary" /> Verified role</span><input value={form.verifyRoleId ?? ''} onChange={(event) => updateField('verifyRoleId', event.target.value)} placeholder="e.g. 118402992…" className="button-focus w-full rounded-xl border hairline bg-background px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/65" data-testid="input-verify-role" /></label>
            </div>
            <label className="mt-5 block"><span className="mb-2 flex items-center gap-2 text-xs font-bold uppercase tracking-[.1em] text-muted-foreground"><MessageSquare className="h-3.5 w-3.5 text-primary" /> Member-facing message</span><textarea value={form.verifyMessage} onChange={(event) => updateField('verifyMessage', event.target.value)} maxLength={2000} rows={4} className="button-focus w-full resize-y rounded-xl border hairline bg-background px-4 py-3 text-sm leading-6 text-foreground placeholder:text-muted-foreground/65" data-testid="input-verify-message" /><span className="mt-1 block text-right font-mono text-[10px] text-muted-foreground">{form.verifyMessage.length} / 2000</span></label>
          </section>
          <section className="panel-shadow rise-in rounded-2xl border hairline bg-card p-5 md:p-7">
            <div className="border-b hairline pb-5"><p className="font-mono text-[10px] uppercase tracking-[.14em] text-primary">03 / The handoff</p><h2 className="mt-1 font-display text-xl font-bold tracking-[-.04em]">Button and role behavior</h2></div>
             <div className="mt-5 grid gap-5 md:grid-cols-3 md:items-end"><label className="block"><span className="mb-2 block text-xs font-bold uppercase tracking-[.1em] text-muted-foreground">Button label</span><input value={form.buttonLabel} onChange={(event) => updateField('buttonLabel', event.target.value)} maxLength={80} className="button-focus w-full rounded-xl border hairline bg-background px-4 py-3 text-sm text-foreground" data-testid="input-button-label" /></label><div className="flex items-center gap-3 rounded-xl bg-secondary/55 p-3.5 md:mb-0"><button type="button" onClick={() => updateField('autoRoleEnabled', !form.autoRoleEnabled)} className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${form.autoRoleEnabled ? 'bg-primary' : 'bg-secondary'}`} data-testid="button-toggle-auto-role"><span className={`absolute top-1 h-5 w-5 rounded-full bg-card shadow-sm transition-transform ${form.autoRoleEnabled ? 'translate-x-6' : 'translate-x-1'}`} /></button><div><p className="text-sm font-bold">Assign role automatically</p><p className="text-xs text-muted-foreground">{form.autoRoleEnabled ? 'Give the verified role after success.' : 'Keep role assignment manual.'}</p></div></div><div className="flex items-center gap-3 rounded-xl bg-secondary/55 p-3.5 md:mb-0"><button type="button" onClick={() => updateField('autoReinviteEnabled', !form.autoReinviteEnabled)} className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${form.autoReinviteEnabled ? 'bg-primary' : 'bg-secondary'}`} data-testid="button-toggle-auto-reinvite"><span className={`absolute top-1 h-5 w-5 rounded-full bg-card shadow-sm transition-transform ${form.autoReinviteEnabled ? 'translate-x-6' : 'translate-x-1'}`} /></button><div><p className="text-sm font-bold">Re-invite after 24h</p><p className="text-xs text-muted-foreground">{form.autoReinviteEnabled ? 'Send a DM invite after a member leaves.' : 'Keep automatic DMs disabled.'}</p></div></div></div>
            <div className="mt-6 rounded-2xl bg-[#202942] p-5 text-white"><p className="font-mono text-[9px] uppercase tracking-[.15em] text-[#9cafc8]">Preview in Discord</p><div className="mt-4 flex gap-3"><DiscordMark small /><div className="min-w-0 flex-1 rounded-xl bg-white/[.08] p-4"><p className="text-sm font-bold">Verifyline <span className="ml-1 rounded bg-[#5865f2] px-1.5 py-0.5 text-[9px] uppercase">BOT</span></p><p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-[#ced8e6]">{form.verifyMessage || 'Your verification message will appear here.'}</p><button type="button" className="mt-4 rounded-lg bg-[#56cfe1] px-3 py-2 text-xs font-bold text-[#132039]" data-testid="button-preview-verify">{form.buttonLabel || 'Verify me'}</button></div></div></div>
          </section>
          <div className="sticky bottom-4 z-10 flex flex-col items-stretch justify-between gap-3 rounded-2xl border hairline bg-card/95 p-3 shadow-[0_15px_35px_rgba(31,43,70,.14)] backdrop-blur sm:flex-row sm:items-center"><p className="px-2 text-xs text-muted-foreground">{config?.updatedAt ? `Last saved ${formatTime(config.updatedAt)}` : 'Changes are saved to this server.'}</p><div className="flex items-center gap-3"><span className={`text-xs font-bold text-[#28704e] transition-opacity ${saved ? 'opacity-100' : 'opacity-0'}`} data-testid="status-settings-saved"><Check className="mr-1 inline h-3.5 w-3.5" /> Saved</span><button type="submit" disabled={update.isPending || !form.verifyMessage.trim() || !form.buttonLabel.trim()} className="button-focus inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-xs font-bold text-primary-foreground transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60" data-testid="button-save-settings">{update.isPending ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} {update.isPending ? 'Saving changes' : 'Save changes'}</button></div></div>
          {update.isError && <QueryError message="Your changes were not saved. Check the fields and try again." />}
        </form>
      )}
    </div>
  );
}

function Router() {
  const [location] = useLocation();
  const guildsQuery = useGetDiscordGuilds({ query: { queryKey: getGetDiscordGuildsQueryKey() } });
  const guilds = guildsQuery.data ?? [];
  const savedId = typeof window !== 'undefined' ? localStorage.getItem('verifyline:selected-guild') : null;
  const guild = guilds.find((item) => item.id === savedId) ?? guilds[0];
  return (
    <Shell>
      {!guild ? null : <Switch location={location}><Route path="/" component={() => <OverviewPage guild={guild} />} /><Route path="/members" component={() => <MembersPage guilds={guilds} />} /><Route path="/settings" component={() => <SettingsPage guild={guild} />} /><Route path="/activity" component={() => <ActivityPage guild={guild} />} /><Route component={NotFound} /></Switch>}
    </Shell>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <RoutedErrorBoundary><AuthGate><Router /></AuthGate></RoutedErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;